"""
run_all.py  — Master POC Orchestrator
=======================================
Data Mesh Platform POC — complete end-to-end pipeline runner.

Stages:
  1  Infrastructure     — Fabric capacity + workspace + networking + identity
  2  On-Prem Ingestion  — Simulate SQL source, extract to parquet, upload to ADLS
  3  Event Pipeline     — Setup Event Grid + Service Bus trigger infrastructure
  4  Silver Transform   — Event-triggered PySpark cleansing notebook
  5  Gold Curation      — Business models: sales_fact, customer_360, product_perf
  6  Warehouse Load     — Fabric Warehouse provisioning + CTAS gold models
  7  Semantic Model     — Power BI Direct Lake model + RLS + CI/CD template
  8  Observability      — Log Analytics + Purview scan + SLO measurement

Run individual stages:
    python run_all.py --stage 1
    python run_all.py --stage 2
    python run_all.py --stage 2 --incremental   (stage 2 incremental load)
    python run_all.py --stage 3 --setup          (create Event Grid infra)
    python run_all.py --stage 3 --consume        (start event consumer)
    python run_all.py --stage 7 --cicd           (print CI/CD template)
    python run_all.py --stage 8 --print-kql      (print KQL dashboard queries)

Run full pipeline (linear, skips infra setup by default):
    python run_all.py --all

Full setup including infrastructure:
    python run_all.py --all --include-infra

Generate JIRAs:
    python run_all.py --jiras

Show architecture:
    python run_all.py --diagram
"""

import sys
import time
import logging
import argparse
import subprocess
from pathlib import Path
from datetime import datetime, timezone

log = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(f"./data/run_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.log"),
    ]
)

ROOT = Path(__file__).parent


# ── Stage definitions ─────────────────────────────────────────────────────────

STAGES = {
    1: {
        "name":    "Infrastructure",
        "plane":   "Data Infrastructure Plane",
        "script":  "poc/01_infrastructure/provision_capacity.py",
        "default_args": [],
        "jiras":   ["INFRA-1", "INFRA-2", "INFRA-3", "INFRA-4"],
        "desc":    "Fabric capacity + workspace + networking + identity provisioning",
    },
    2: {
        "name":    "On-Prem Ingestion",
        "plane":   "Data Platform Plane",
        "script":  "poc/02_ingestion/simulate_onprem.py",
        "default_args": ["--mode", "full"],
        "jiras":   ["INGEST-1", "INGEST-2", "INGEST-3"],
        "desc":    "Simulate on-prem SQL → extract parquet → upload ADLS raw-zone with lineage tags",
    },
    3: {
        "name":    "Event Pipeline Setup",
        "plane":   "Data Platform Plane",
        "script":  "poc/03_event_pipeline/trigger_fabric_job.py",
        "default_args": ["--setup"],
        "jiras":   ["EVENT-1", "EVENT-2", "EVENT-3"],
        "desc":    "Event Grid + Service Bus + Fabric job trigger (CopyJob / Notebook routing)",
    },
    4: {
        "name":    "Silver Transform",
        "plane":   "Data Product Plane",
        "script":  "poc/04_data_engineering/silver_transform.py",
        "default_args": [],
        "jiras":   ["DE-1"],
        "desc":    "PySpark silver cleansing: DQ rules, workspace MSI auth, Iceberg write to ADLS",
        "note":    "Run inside Fabric notebook or trigger via Event pipeline (stage 3)",
    },
    5: {
        "name":    "Gold Curation",
        "plane":   "Data Product Plane",
        "script":  "poc/04_data_engineering/gold_curated.py",
        "default_args": [],
        "jiras":   ["DE-2"],
        "desc":    "Gold business models: sales_fact, customer_360 (RFM), product_performance",
        "note":    "Run inside Fabric notebook after silver (stage 4) completes",
    },
    6: {
        "name":    "Warehouse",
        "plane":   "Data Product Plane",
        "script":  "poc/05_warehouse/provision_warehouse.py",
        "default_args": ["--all"],
        "jiras":   ["DE-3"],
        "desc":    "Fabric Warehouse: provision + CTAS gold models + JDBC connection string",
    },
    7: {
        "name":    "Semantic Model",
        "plane":   "Data Product Plane",
        "script":  "poc/06_semantic_model/create_semantic_model.py",
        "default_args": ["--create", "--validate"],
        "jiras":   ["PBI-1", "PBI-2", "PBI-3"],
        "desc":    "Power BI Direct Lake semantic model + RLS + CI/CD GitHub Actions template",
    },
    8: {
        "name":    "Observability",
        "plane":   "Infrastructure Plane",
        "script":  "poc/07_observability/setup_monitoring.py",
        "default_args": ["--print-kql"],
        "jiras":   ["OBS-1", "OBS-2", "OBS-3", "GOV-1", "GOV-2", "GOV-3"],
        "desc":    "Log Analytics + Purview scan + SLO measurement + KQL dashboards",
    },
}


# ── Runner ────────────────────────────────────────────────────────────────────

def run_stage(stage_num: int, extra_args: list[str] = None) -> bool:
    stage    = STAGES[stage_num]
    script   = ROOT / stage["script"]
    args     = extra_args if extra_args is not None else stage["default_args"]

    if not script.exists():
        log.warning("  Script not found: %s — skipping", script)
        return True

    cmd = [sys.executable, str(script)] + args
    log.info("")
    log.info("━" * 65)
    log.info("  STAGE %d: %s", stage_num, stage["name"].upper())
    log.info("  Plane : %s", stage["plane"])
    log.info("  Desc  : %s", stage["desc"])
    if stage.get("note"):
        log.info("  NOTE  : %s", stage["note"])
    log.info("  JIRAs : %s", "  ".join(stage["jiras"]))
    log.info("  CMD   : %s", " ".join(str(a) for a in cmd))
    log.info("━" * 65)

    t0 = time.time()
    try:
        result = subprocess.run(cmd, cwd=ROOT, timeout=600)
        dur    = time.time() - t0
        ok     = result.returncode == 0
        status = "✓ PASS" if ok else "✗ FAIL"
        log.info("%s  Stage %d: %s  (%.1fs)", status, stage_num, stage["name"], dur)
        return ok
    except subprocess.TimeoutExpired:
        log.error("✗ Stage %d timed out after 600s", stage_num)
        return False
    except Exception as e:
        log.error("✗ Stage %d error: %s", stage_num, e)
        return False


# ── ASCII diagram ─────────────────────────────────────────────────────────────

DIAGRAM = """
╔══════════════════════════════════════════════════════════════════════════════╗
║         DATA MESH PLATFORM — END-TO-END POC ARCHITECTURE                   ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  ┌──────────────────────────────────────────────────────────────────────┐   ║
║  │  DATA INFRASTRUCTURE PLANE (Platform Engineering — Stage 1)         │   ║
║  │  Fabric Capacity (F2→F64)  ·  Workspaces/domain  ·  Private Net     │   ║
║  │  Entra Groups  ·  PIM  ·  Immuta Contracts  ·  Wiz Cloud Connector  │   ║
║  └──────────────────────────────────────────────────────────────────────┘   ║
║                                                                              ║
║  ┌────────────────────┐                                                      ║
║  │ ON-PREM SQL        │  Stage 2: Python extract                            ║
║  │ (SQLite sim)       │──────────────────────────►  ADLS raw-zone           ║
║  │ Full + Incr + CDC  │  checksum + lineage tags    tpcds/tables/{t}/       ║
║  └────────────────────┘                                    │                ║
║                                                            │ Stage 3        ║
║                                              Event Grid (BlobCreated)       ║
║                                                            │                ║
║                                              Service Bus tpcds-raw-ingest   ║
║                                                            │                ║
║                                      ┌─────────────────────┴──────────┐    ║
║                                      │ Consumer: route by table type   │    ║
║                                      │  dimension → CopyJob (Fabric)   │    ║
║                                      │  fact      → coordinate silver  │    ║
║                                      └───────┬─────────────────────────┘    ║
║                                              │                              ║
║                        ┌─────────────────────┼───────────────────────┐     ║
║                        ▼                     ▼                       ▼     ║
║                  Fabric CopyJob         Silver NB (Stage 4)     Gold NB   ║
║                  raw→Iceberg            PySpark DQ              (Stage 5) ║
║                  prepared-zone          cleanse/conform         business   ║
║                  tpcds/iceberg          tpcds/silver/           models     ║
║                                                                  tpcds/gold║
║                        │                                             │     ║
║                        └─────────────┬───────────────────────────────┘     ║
║                                      │                                      ║
║                            Lakehouse shortcuts (CATALOG ONLY)               ║
║                            Tables/dbo/{table} → ADLS path                  ║
║                            Zero data in OneLake                             ║
║                                      │                                      ║
║                          ┌───────────┴───────────┐                         ║
║                          ▼                       ▼                         ║
║                   Fabric Warehouse        Power BI Direct Lake             ║
║                   T-SQL ETL (Stage 6)     Semantic Model (Stage 7)        ║
║                   gold.sales_fact         gold_sales_fact                  ║
║                   gold.customer_360       gold_customer_360                 ║
║                   gold.product_perf       gold_product_performance          ║
║                   JDBC/ODBC conn str      RLS: domain-scoped               ║
║                                                                              ║
║  ┌──────────────────────────────────────────────────────────────────────┐   ║
║  │  OBSERVABILITY PLANE (Stage 8)                                       │   ║
║  │  Log Analytics (DataPipelineRun, DQ, Ingestion, JobTrigger, SLO)    │   ║
║  │  Purview lineage scan · SLO freshness/quality/availability           │   ║
║  │  Immuta · Purview DLP · Wiz (Central team agentless)                │   ║
║  └──────────────────────────────────────────────────────────────────────┘   ║
║                                                                              ║
║  SECURITY: Workspace MSI → Immuta (PDP) → OneLake plane → Purview DLP      ║
║            → Azure Storage RBAC · No secrets in code · Item-level roles    ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    Path("./data").mkdir(exist_ok=True)

    parser = argparse.ArgumentParser(
        description="Data Mesh Platform POC — master runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--stage",         type=int, choices=list(STAGES.keys()),
                        help="Run a specific stage (1-8)")
    parser.add_argument("--all",           action="store_true", help="Run all stages 2-8")
    parser.add_argument("--include-infra", action="store_true", help="Include stage 1 (infra) in --all")
    parser.add_argument("--jiras",         action="store_true", help="Generate JIRA board + JSON export")
    parser.add_argument("--diagram",       action="store_true", help="Print architecture diagram")
    parser.add_argument("--list",          action="store_true", help="List all stages")
    # Pass-through args for individual stages
    parser.add_argument("--incremental",   action="store_true", help="Stage 2: incremental extract mode")
    parser.add_argument("--delta",         action="store_true", help="Stage 2: generate CDC delta first")
    parser.add_argument("--setup",         action="store_true", help="Stage 3: create Event Grid infra")
    parser.add_argument("--consume",       action="store_true", help="Stage 3: start consumer loop")
    parser.add_argument("--cicd",          action="store_true", help="Stage 7: print CI/CD template")
    parser.add_argument("--print-kql",     action="store_true", help="Stage 8: print KQL queries")
    args = parser.parse_args()

    print("""
  ██████╗  █████╗ ████████╗ █████╗     ███╗   ███╗███████╗███████╗██╗  ██╗
  ██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗    ████╗ ████║██╔════╝██╔════╝██║  ██║
  ██║  ██║███████║   ██║   ███████║    ██╔████╔██║█████╗  ███████╗███████║
  ██║  ██║██╔══██║   ██║   ██╔══██║    ██║╚██╔╝██║██╔══╝  ╚════██║██╔══██║
  ██████╔╝██║  ██║   ██║   ██║  ██║    ██║ ╚═╝ ██║███████╗███████║██║  ██║
  ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝    ╚═╝     ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝
  PLATFORM POC  ·  Multi-Plane Data Mesh  ·  Microsoft Fabric + ADLS
""")

    if args.diagram:
        print(DIAGRAM)
        return

    if args.list:
        print(f"\n{'Stage':<7} {'Name':<22} {'Plane':<28} {'JIRAs'}")
        print("─" * 80)
        for n, s in STAGES.items():
            print(f"  {n:<5} {s['name']:<22} {s['plane']:<28} {', '.join(s['jiras'])}")
        return

    if args.jiras:
        log.info("Generating JIRA backlog...")
        result = subprocess.run(
            [sys.executable, str(ROOT / "jiras" / "generate_jiras.py"), "--no-browser"],
            cwd=ROOT
        )
        if result.returncode == 0:
            log.info("✓ JIRA export: jiras/jira_export.json")
            log.info("✓ JIRA board : jiras/jira_board.html")
        return

    if args.stage:
        n = args.stage
        extra = []
        if n == 2:
            if args.incremental:
                extra = ["--mode", "incremental"]
            if args.delta:
                extra += ["--generate-delta"]
        elif n == 3:
            if args.consume:
                extra = ["--consume"]
            elif args.setup:
                extra = ["--setup"]
        elif n == 7 and args.cicd:
            extra = ["--cicd"]
        elif n == 8 and args.print_kql:
            extra = ["--print-kql"]
        ok = run_stage(n, extra if extra else None)
        sys.exit(0 if ok else 1)

    if args.all:
        start_stage = 1 if args.include_infra else 2
        stages_to_run = list(range(start_stage, 9))
        log.info("Running stages: %s", stages_to_run)

        results = {}
        for n in stages_to_run:
            # Stages 4 and 5 run inside Fabric — skip here with info
            if n in (4, 5):
                log.info("\n── Stage %d (%s): runs inside Fabric notebook ──", n, STAGES[n]["name"])
                log.info("   Upload notebook via Fabric portal or provisioning script")
                log.info("   JIRAs: %s", ", ".join(STAGES[n]["jiras"]))
                results[n] = "skipped"
                continue
            ok = run_stage(n)
            results[n] = "pass" if ok else "fail"
            if not ok and n <= 3:
                log.error("Critical stage %d failed — aborting", n)
                break

        log.info("\n" + "═" * 65)
        log.info("  PIPELINE SUMMARY")
        log.info("═" * 65)
        for n, status in results.items():
            icon = {"pass": "✓", "fail": "✗", "skipped": "↷"}.get(status, "?")
            log.info("  %s  Stage %d: %-22s %s", icon, n, STAGES[n]["name"], status)
        log.info("═" * 65)
        sys.exit(0 if all(v in ("pass","skipped") for v in results.values()) else 1)

    parser.print_help()
    print("\nQuick start:")
    print("  python run_all.py --diagram             # architecture overview")
    print("  python run_all.py --list                # list all stages")
    print("  python run_all.py --jiras               # generate JIRA board")
    print("  python run_all.py --stage 2             # on-prem upload POC")
    print("  python run_all.py --stage 2 --delta     # with CDC delta")
    print("  python run_all.py --stage 8 --print-kql # KQL dashboard queries")
    print("  python run_all.py --all                 # full pipeline")


if __name__ == "__main__":
    main()
