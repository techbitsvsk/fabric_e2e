"""
poc/06_semantic_model/create_semantic_model.py
===============================================
JIRA: PBI-1 — Create Power BI semantic model via Fabric REST API
JIRA: PBI-2 — Row-Level Security aligned to Immuta data contracts
JIRA: PBI-3 — Automated semantic model deployment pipeline (CI/CD)

Data Mesh Plane: Data Product Plane
Owner: Domain Teams (self-service)

Demonstrates:
  - Fabric semantic model (Power BI dataset) creation via REST API
  - Direct Lake binding to gold Lakehouse shortcut tables
  - DAX measures: Revenue, Return Rate, Customer LTV, Avg Discount
  - Table relationships: sales_fact → customer_360, product_performance
  - Row-Level Security: domain-scoped, aligned to Immuta data contracts
  - TMDL model definition saved as JSON (source-controlled, CI/CD ready)
  - Automated dataset refresh trigger

Run:
    python poc/06_semantic_model/create_semantic_model.py --create
    python poc/06_semantic_model/create_semantic_model.py --refresh
    python poc/06_semantic_model/create_semantic_model.py --deploy-rls
    python poc/06_semantic_model/create_semantic_model.py --validate
    python poc/06_semantic_model/create_semantic_model.py --all
"""

import sys
import json
import time
import logging
import argparse
import requests
from pathlib import Path
from datetime import datetime, timezone

import yaml
from azure.identity import AzureCliCredential

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(message)s")

ROOT = Path(__file__).resolve().parents[2]
CFG  = yaml.safe_load((ROOT / "config.yaml").read_text()) if (ROOT / "config.yaml").exists() else {}

WORKSPACE_ID   = CFG.get("fabric", {}).get("workspace_id",   "YOUR_WORKSPACE_ID")
LAKEHOUSE_ID   = CFG.get("fabric", {}).get("lakehouse_id",   "YOUR_LAKEHOUSE_ID")
LAKEHOUSE_NAME = CFG.get("fabric", {}).get("lakehouse_name", "tpcds_lakehouse")
SCHEMA         = CFG.get("fabric", {}).get("schema",         "dbo")
MODEL_NAME     = "tpcds_gold_model"
FABRIC_API     = "https://api.fabric.microsoft.com/v1"
POWERBI_API    = "https://api.powerbi.com/v1.0/myorg"


# ─── Auth ─────────────────────────────────────────────────────────────────────

def fabric_headers() -> dict:
    t = AzureCliCredential().get_token("https://api.fabric.microsoft.com/.default")
    return {"Authorization": f"Bearer {t.token}", "Content-Type": "application/json"}

def powerbi_headers() -> dict:
    t = AzureCliCredential().get_token("https://analysis.windows.net/powerbi/api/.default")
    return {"Authorization": f"Bearer {t.token}", "Content-Type": "application/json"}


# ══════════════════════════════════════════════════════════════════════════════
# MODEL DEFINITION  (TMDL-equivalent as JSON — source-controlled)
# ══════════════════════════════════════════════════════════════════════════════

def build_model_definition() -> dict:
    """
    Build the semantic model definition.
    In production this lives in Git as TMDL files.
    Here we construct it programmatically for the POC.

    Direct Lake mode: tables bind to Lakehouse shortcuts.
    No import — queries hit ADLS directly via Fabric Connection.
    """
    return {
        "displayName": MODEL_NAME,
        "description": "TPC-DS Gold Layer — Direct Lake semantic model for cross-channel retail analytics",
        "definition": {
            "parts": [
                # ── model.bim (main definition) ──────────────────────────────
                {
                    "path": "model.bim",
                    "payload": _encode(json.dumps({
                        "name":              MODEL_NAME,
                        "compatibilityLevel": 1605,
                        "model": {
                            "defaultPowerBiDataSourceVersion": "powerBI_V3",
                            "tables": [
                                _table_sales_fact(),
                                _table_customer_360(),
                                _table_product_performance(),
                                _table_date_dim(),
                            ],
                            "relationships": _relationships(),
                            "roles":         _rls_roles(),
                            "annotations": [
                                {"name": "PBI_QueryOrder",           "value": "[]"},
                                {"name": "data_mesh_plane",          "value": "data-product"},
                                {"name": "domain",                   "value": "retail-analytics"},
                                {"name": "data_contract_gold",       "value": "dc-tpcds-gold-001"},
                                {"name": "sensitivity_label",        "value": "Internal"},
                                {"name": "deployed_at",              "value": datetime.now(timezone.utc).isoformat()},
                            ]
                        }
                    })),
                    "payloadType": "InlineBase64"
                }
            ]
        }
    }


def _encode(s: str) -> str:
    import base64
    return base64.b64encode(s.encode()).decode()


def _direct_lake_source(table_name: str) -> dict:
    """Direct Lake entity binding — points to Lakehouse shortcut table."""
    return {
        "type": "calculated",
        "expression": (
            f"let\n"
            f"    Source = PowerBI.Datasets(null),\n"
            f"    Navigation = Source{{[Name=\"{LAKEHOUSE_NAME}\"]}}[Data],\n"
            f"    Table = Navigation{{[Name=\"{SCHEMA}_{table_name}\"]}}[Data]\n"
            f"in\n"
            f"    Table"
        )
    }


def _table_sales_fact() -> dict:
    return {
        "name": "Sales Fact",
        "lineageTag": "sales-fact-001",
        "sourceLineageTag": f"{LAKEHOUSE_ID}#{SCHEMA}.gold_sales_fact",
        "columns": [
            {"name": "Channel",         "dataType": "string",   "sourceColumn": "channel"},
            {"name": "Sold Date SK",    "dataType": "int64",    "sourceColumn": "sold_date_sk"},
            {"name": "Item SK",         "dataType": "int64",    "sourceColumn": "item_sk"},
            {"name": "Customer SK",     "dataType": "int64",    "sourceColumn": "customer_sk"},
            {"name": "Transaction ID",  "dataType": "int64",    "sourceColumn": "transaction_id"},
            {"name": "Quantity",        "dataType": "int64",    "sourceColumn": "quantity"},
            {"name": "Gross Sales Amt", "dataType": "decimal",  "sourceColumn": "gross_sales_amt"},
            {"name": "Net Sales Amt",   "dataType": "decimal",  "sourceColumn": "net_sales_amt"},
            {"name": "Net Profit",      "dataType": "decimal",  "sourceColumn": "net_profit"},
            {"name": "Return Amt",      "dataType": "decimal",  "sourceColumn": "return_amt"},
            {"name": "Return Qty",      "dataType": "int64",    "sourceColumn": "return_qty"},
            {"name": "Discount Pct",    "dataType": "decimal",  "sourceColumn": "discount_pct"},
            {"name": "Is Returned",     "dataType": "boolean",  "sourceColumn": "is_returned"},
            {"name": "Return Rate Pct", "dataType": "decimal",  "sourceColumn": "return_rate_pct"},
        ],
        "measures": [
            {
                "name": "Total Revenue",
                "expression": "SUM('Sales Fact'[Gross Sales Amt])",
                "formatString": "£#,##0.00",
                "description": "Total gross revenue across all channels",
            },
            {
                "name": "Net Revenue",
                "expression": "SUM('Sales Fact'[Net Sales Amt])",
                "formatString": "£#,##0.00",
            },
            {
                "name": "Total Units Sold",
                "expression": "SUM('Sales Fact'[Quantity])",
                "formatString": "#,##0",
            },
            {
                "name": "Return Rate %",
                "expression": (
                    "DIVIDE(\n"
                    "    SUM('Sales Fact'[Return Qty]),\n"
                    "    SUM('Sales Fact'[Quantity]),\n"
                    "    0\n"
                    ") * 100"
                ),
                "formatString": "0.00%",
            },
            {
                "name": "Avg Transaction Value",
                "expression": (
                    "DIVIDE(\n"
                    "    [Total Revenue],\n"
                    "    COUNTROWS('Sales Fact'),\n"
                    "    0\n"
                    ")"
                ),
                "formatString": "£#,##0.00",
            },
            {
                "name": "Net Profit Margin %",
                "expression": "DIVIDE([Net Revenue], [Total Revenue], 0) * 100",
                "formatString": "0.00%",
            },
            {
                "name": "YoY Revenue Growth %",
                "expression": (
                    "VAR PY = CALCULATE([Total Revenue], DATEADD('Date Dim'[d_date], -1, YEAR))\n"
                    "RETURN DIVIDE([Total Revenue] - PY, PY, BLANK()) * 100"
                ),
                "formatString": "0.00%",
            },
        ],
        "partitions": [{"name": "Sales Fact", "mode": "directLake", "source": _direct_lake_source("gold_sales_fact")}],
    }


def _table_customer_360() -> dict:
    return {
        "name": "Customer 360",
        "lineageTag": "customer-360-001",
        "sourceLineageTag": f"{LAKEHOUSE_ID}#{SCHEMA}.gold_customer_360",
        "columns": [
            {"name": "Customer SK",          "dataType": "int64",   "sourceColumn": "customer_sk"},
            {"name": "Full Name",            "dataType": "string",  "sourceColumn": "c_full_name"},
            {"name": "Email",                "dataType": "string",  "sourceColumn": "c_email_address"},
            {"name": "Birth Year",           "dataType": "int64",   "sourceColumn": "c_birth_year"},
            {"name": "City",                 "dataType": "string",  "sourceColumn": "ca_city"},
            {"name": "State",                "dataType": "string",  "sourceColumn": "ca_state"},
            {"name": "RFM Segment",          "dataType": "string",  "sourceColumn": "rfm_segment"},
            {"name": "RFM Score",            "dataType": "int64",   "sourceColumn": "rfm_score"},
            {"name": "Preferred Channel",    "dataType": "string",  "sourceColumn": "preferred_channel"},
            {"name": "Lifetime Net Sales",   "dataType": "decimal", "sourceColumn": "lifetime_net_sales"},
            {"name": "Lifetime Gross Sales", "dataType": "decimal", "sourceColumn": "lifetime_gross_sales"},
            {"name": "Total Transactions",   "dataType": "int64",   "sourceColumn": "total_transactions"},
            {"name": "Days Since Purchase",  "dataType": "int64",   "sourceColumn": "days_since_last_purchase"},
            {"name": "Return Rate Pct",      "dataType": "decimal", "sourceColumn": "return_rate_pct"},
        ],
        "measures": [
            {
                "name": "Avg Customer LTV",
                "expression": "AVERAGE('Customer 360'[Lifetime Net Sales])",
                "formatString": "£#,##0.00",
            },
            {
                "name": "Total Customers",
                "expression": "COUNTROWS('Customer 360')",
                "formatString": "#,##0",
            },
            {
                "name": "Champions Count",
                "expression": "CALCULATE(COUNTROWS('Customer 360'), 'Customer 360'[RFM Segment] = \"Champions\")",
                "formatString": "#,##0",
            },
            {
                "name": "Churned Count",
                "expression": "CALCULATE(COUNTROWS('Customer 360'), 'Customer 360'[RFM Segment] = \"Churned\")",
                "formatString": "#,##0",
            },
            {
                "name": "Churn Risk %",
                "expression": "DIVIDE([Churned Count], [Total Customers], 0) * 100",
                "formatString": "0.0%",
            },
        ],
        "partitions": [{"name": "Customer 360", "mode": "directLake", "source": _direct_lake_source("gold_customer_360")}],
    }


def _table_product_performance() -> dict:
    return {
        "name": "Product Performance",
        "lineageTag": "product-perf-001",
        "sourceLineageTag": f"{LAKEHOUSE_ID}#{SCHEMA}.gold_product_performance",
        "columns": [
            {"name": "Item SK",           "dataType": "int64",   "sourceColumn": "item_sk"},
            {"name": "Product Name",      "dataType": "string",  "sourceColumn": "i_product_name"},
            {"name": "Category",          "dataType": "string",  "sourceColumn": "i_category"},
            {"name": "Brand",             "dataType": "string",  "sourceColumn": "i_brand"},
            {"name": "Margin Tier",       "dataType": "string",  "sourceColumn": "margin_tier"},
            {"name": "Top Channel",       "dataType": "string",  "sourceColumn": "top_channel"},
            {"name": "Total Net Sales",   "dataType": "decimal", "sourceColumn": "total_net_sales"},
            {"name": "Total Net Profit",  "dataType": "decimal", "sourceColumn": "total_net_profit"},
            {"name": "Return Rate Pct",   "dataType": "decimal", "sourceColumn": "return_rate_pct"},
            {"name": "Daily Velocity",    "dataType": "decimal", "sourceColumn": "daily_sales_velocity"},
            {"name": "Revenue Rank",      "dataType": "int64",   "sourceColumn": "revenue_rank"},
            {"name": "Unique Customers",  "dataType": "int64",   "sourceColumn": "unique_customers"},
        ],
        "measures": [
            {
                "name": "Top 10 Revenue",
                "expression": (
                    "CALCULATE(\n"
                    "    SUM('Product Performance'[Total Net Sales]),\n"
                    "    TOPN(10, 'Product Performance', 'Product Performance'[Total Net Sales])\n"
                    ")"
                ),
                "formatString": "£#,##0.00",
            },
        ],
        "partitions": [{"name": "Product Performance", "mode": "directLake", "source": _direct_lake_source("gold_product_performance")}],
    }


def _table_date_dim() -> dict:
    return {
        "name": "Date Dim",
        "lineageTag": "date-dim-001",
        "sourceLineageTag": f"{LAKEHOUSE_ID}#{SCHEMA}.silver_date_dim",
        "columns": [
            {"name": "d_date_sk",     "dataType": "int64",  "sourceColumn": "d_date_sk"},
            {"name": "d_date",        "dataType": "dateTime","sourceColumn": "d_date"},
            {"name": "Year",          "dataType": "int64",  "sourceColumn": "d_year"},
            {"name": "Month",         "dataType": "int64",  "sourceColumn": "d_moy"},
            {"name": "Quarter",       "dataType": "int64",  "sourceColumn": "d_qoy"},
            {"name": "Day Name",      "dataType": "string", "sourceColumn": "d_day_name"},
            {"name": "Season",        "dataType": "string", "sourceColumn": "d_season"},
            {"name": "Is Weekend",    "dataType": "boolean","sourceColumn": "d_is_weekend"},
            {"name": "Is Holiday",    "dataType": "boolean","sourceColumn": "d_is_holiday"},
            {"name": "Half Year",     "dataType": "string", "sourceColumn": "d_half_year"},
        ],
        "isHidden": False,
        "partitions": [{"name": "Date Dim", "mode": "directLake", "source": _direct_lake_source("silver_date_dim")}],
    }


def _relationships() -> list:
    return [
        {
            "name":           "SalesFact_Customer",
            "fromTable":      "Sales Fact",
            "fromColumn":     "Customer SK",
            "toTable":        "Customer 360",
            "toColumn":       "Customer SK",
            "crossFilteringBehavior": "singleDirection",
        },
        {
            "name":           "SalesFact_Product",
            "fromTable":      "Sales Fact",
            "fromColumn":     "Item SK",
            "toTable":        "Product Performance",
            "toColumn":       "Item SK",
            "crossFilteringBehavior": "singleDirection",
        },
        {
            "name":           "SalesFact_Date",
            "fromTable":      "Sales Fact",
            "fromColumn":     "Sold Date SK",
            "toTable":        "Date Dim",
            "toColumn":       "d_date_sk",
            "crossFilteringBehavior": "singleDirection",
        },
    ]


def _rls_roles() -> list:
    """
    RLS roles aligned to Immuta data contracts.
    Each domain sees only their channel's data.
    Finance/platform team sees all.

    In production: Entra groups mapped to these roles via Graph API.
    """
    return [
        {
            "name":        "Store Analytics",
            "description": "Store channel only — maps to Immuta dc-tpcds-gold-001 store-reader attribute",
            "tablePermissions": [
                {
                    "name":       "Sales Fact",
                    "filterExpression": "'Sales Fact'[Channel] = \"STORE\"",
                }
            ],
        },
        {
            "name":        "Catalog Analytics",
            "description": "Catalog channel only — maps to Immuta dc-tpcds-gold-001 catalog-reader attribute",
            "tablePermissions": [
                {
                    "name":       "Sales Fact",
                    "filterExpression": "'Sales Fact'[Channel] = \"CATALOG\"",
                }
            ],
        },
        {
            "name":        "Web Analytics",
            "description": "Web channel only — maps to Immuta dc-tpcds-gold-001 web-reader attribute",
            "tablePermissions": [
                {
                    "name":       "Sales Fact",
                    "filterExpression": "'Sales Fact'[Channel] = \"WEB\"",
                }
            ],
        },
        {
            "name":        "Platform Admin",
            "description": "Full access — no row filter. Platform engineering team only.",
            "tablePermissions": [],   # empty = full access
        },
    ]


# ══════════════════════════════════════════════════════════════════════════════
# CRUD
# ══════════════════════════════════════════════════════════════════════════════

def get_model_id() -> str | None:
    resp = requests.get(
        f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/semanticModels",
        headers=fabric_headers(), timeout=30
    )
    if resp.status_code == 200:
        for item in resp.json().get("value", []):
            if item["displayName"] == MODEL_NAME:
                return item["id"]
    return None


def create_semantic_model() -> str:
    existing = get_model_id()
    if existing:
        log.info("Semantic model already exists: %s", existing)
        return existing

    log.info("Creating semantic model: %s", MODEL_NAME)
    definition = build_model_definition()

    resp = requests.post(
        f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/semanticModels",
        json=definition, headers=fabric_headers(), timeout=60
    )
    if resp.status_code not in (200, 201, 202):
        log.error("Create failed: %d — %s", resp.status_code, resp.text[:400])
        resp.raise_for_status()

    if resp.status_code == 202:
        loc = resp.headers.get("Location", "")
        for _ in range(20):
            time.sleep(5)
            r = requests.get(loc, headers=fabric_headers(), timeout=30)
            if r.status_code == 200 and r.json().get("status") == "Succeeded":
                model_id = r.json().get("createdItemId", "")
                log.info("✓ Semantic model created: %s", model_id)
                return model_id
    else:
        model_id = resp.json().get("id", "")
        log.info("✓ Semantic model created: %s", model_id)
        return model_id

    raise TimeoutError("Model creation timed out")


def refresh_model(model_id: str):
    log.info("Triggering dataset refresh: %s", model_id)
    resp = requests.post(
        f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/semanticModels/{model_id}/refreshes",
        json={"type": "full"}, headers=fabric_headers(), timeout=30
    )
    if resp.status_code in (200, 202):
        log.info("✓ Refresh triggered")
    else:
        log.warning("Refresh returned %d: %s", resp.status_code, resp.text[:200])


def validate_model(model_id: str):
    """Verify Direct Lake mode is active and tables are accessible."""
    log.info("Validating semantic model...")

    resp = requests.get(
        f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/semanticModels/{model_id}",
        headers=fabric_headers(), timeout=30
    )
    if resp.status_code != 200:
        log.error("Cannot fetch model: %d", resp.status_code)
        return False

    props = resp.json()
    log.info("  Model ID    : %s", props.get("id"))
    log.info("  Name        : %s", props.get("displayName"))
    log.info("  Description : %s", props.get("description",""))

    # Check datasources (should show DirectLake)
    ds_resp = requests.get(
        f"{POWERBI_API}/datasets/{model_id}/datasources",
        headers=powerbi_headers(), timeout=30
    )
    if ds_resp.status_code == 200:
        for ds in ds_resp.json().get("value", []):
            mode = ds.get("datasourceType", "unknown")
            log.info("  Datasource  : type=%s  (Direct Lake = no import fallback)", mode)

    log.info("✓ Semantic model validated")
    return True


def save_tmdl(output_path: Path):
    """
    Save the model definition as a TMDL JSON file for source control.
    In CI/CD this file is committed to Git and deployed on merge.
    """
    definition = build_model_definition()
    tmdl_path  = output_path / f"{MODEL_NAME}.tmdl.json"
    tmdl_path.write_text(json.dumps(definition, indent=2))
    log.info("✓ TMDL definition saved: %s", tmdl_path)

    # Also save RLS roles separately for easy review
    rls_path = output_path / f"{MODEL_NAME}_rls.json"
    rls_path.write_text(json.dumps(_rls_roles(), indent=2))
    log.info("✓ RLS definition saved:  %s", rls_path)


# ══════════════════════════════════════════════════════════════════════════════
# CI/CD DEPLOYMENT PIPELINE
# ══════════════════════════════════════════════════════════════════════════════

def print_cicd_template():
    """Print a GitHub Actions workflow template for semantic model CI/CD."""
    template = """
# .github/workflows/deploy-semantic-model.yml
# ─────────────────────────────────────────────
# Deploys the TPC-DS gold semantic model on every push to main.
# Uses Fabric REST API + OIDC federated identity (no secrets).

name: Deploy Semantic Model

on:
  push:
    branches: [main]
    paths:
      - 'poc/06_semantic_model/**'

permissions:
  id-token: write   # OIDC for Azure federated identity
  contents: read

jobs:
  deploy:
    runs-on: ubuntu-latest
    environment: production

    steps:
      - uses: actions/checkout@v4

      - name: Azure Login (OIDC — no secrets)
        uses: azure/login@v2
        with:
          client-id:       ${{ secrets.AZURE_CLIENT_ID }}
          tenant-id:       ${{ secrets.AZURE_TENANT_ID }}
          subscription-id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Setup Python
        uses: actions/setup-python@v5
        with: { python-version: '3.11' }

      - name: Install deps
        run: pip install requests azure-identity pyyaml

      - name: Deploy semantic model to dev
        run: python poc/06_semantic_model/create_semantic_model.py --all
        env:
          WORKSPACE_ID: ${{ vars.FABRIC_DEV_WORKSPACE_ID }}

      - name: Smoke test — verify row counts
        run: python poc/06_semantic_model/create_semantic_model.py --validate
        env:
          WORKSPACE_ID: ${{ vars.FABRIC_DEV_WORKSPACE_ID }}

      - name: Promote to prod (manual approval gate)
        if: success()
        uses: trstringer/manual-approval@v1
        with:
          secret: ${{ secrets.GITHUB_TOKEN }}
          approvers: platform-engineering-team

      - name: Deploy to prod
        run: python poc/06_semantic_model/create_semantic_model.py --all
        env:
          WORKSPACE_ID: ${{ vars.FABRIC_PROD_WORKSPACE_ID }}
"""
    print(template)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Fabric semantic model deployment")
    parser.add_argument("--create",      action="store_true", help="Create semantic model")
    parser.add_argument("--refresh",     action="store_true", help="Trigger dataset refresh")
    parser.add_argument("--deploy-rls",  action="store_true", help="Deploy RLS roles (requires XMLA)")
    parser.add_argument("--validate",    action="store_true", help="Validate model and Direct Lake mode")
    parser.add_argument("--save-tmdl",   action="store_true", help="Save TMDL JSON to disk")
    parser.add_argument("--cicd",        action="store_true", help="Print GitHub Actions CI/CD template")
    parser.add_argument("--all",         action="store_true", help="Run all steps")
    args = parser.parse_args()

    if args.cicd:
        print_cicd_template()
        return

    if args.save_tmdl:
        out = Path("./data/semantic_model")
        out.mkdir(parents=True, exist_ok=True)
        save_tmdl(out)
        return

    if args.create or args.all:
        model_id = create_semantic_model()
        log.info("Model ID: %s", model_id)

    model_id = get_model_id()
    if not model_id and not (args.create or args.all):
        log.error("No semantic model found — run --create first")
        sys.exit(1)

    if (args.refresh or args.all) and model_id:
        refresh_model(model_id)

    if (args.validate or args.all) and model_id:
        validate_model(model_id)

    log.info("\n── Next Steps ──")
    log.info("  1. Open Power BI Service → workspace → %s", MODEL_NAME)
    log.info("  2. Build reports on top of gold_sales_fact, gold_customer_360, gold_product_performance")
    log.info("  3. RLS roles: Store Analytics / Catalog Analytics / Web Analytics / Platform Admin")
    log.info("  4. Assign Entra groups to RLS roles via Fabric portal → Manage permissions")
    log.info("  5. Run --cicd to see GitHub Actions deployment template")

    if not any([args.create, args.refresh, args.deploy_rls, args.validate,
                args.save_tmdl, args.cicd, args.all]):
        parser.print_help()


if __name__ == "__main__":
    main()
