"""
poc/02_ingestion/simulate_onprem.py
=====================================
JIRA: INGEST-1 — Simulate on-premises SQL source, extract to parquet
JIRA: INGEST-2 — Upload to ADLS Gen2 with lineage metadata tagging
JIRA: INGEST-3 — Incremental load with watermark and CDC simulation

Data Mesh Plane: Data Platform Plane
Owner: Data Platform Engineering Team

Demonstrates end-to-end on-prem → cloud movement:
  1. SQLite database simulates an on-premises SQL Server (TPC-DS schema)
  2. Full extract:        all dimension tables → parquet
  3. Incremental extract: fact tables via watermark (last_modified tracking)
  4. CDC simulation:      insert / update / delete operation column
  5. Upload to ADLS:      raw-zone with SHA-256 checksum + lineage blob tags
  6. Manifest written:    raw-zone/_manifests/{date}/{table}.json

Run:
    # Full extract + upload all tables
    python poc/02_ingestion/simulate_onprem.py

    # Incremental only (subsequent runs)
    python poc/02_ingestion/simulate_onprem.py --mode incremental

    # Generate new deltas (simulates new on-prem data arriving)
    python poc/02_ingestion/simulate_onprem.py --generate-delta

    # Dry run (extract only, no upload)
    python poc/02_ingestion/simulate_onprem.py --dry-run
"""

import os
import sys
import json
import time
import hashlib
import logging
import sqlite3
import argparse
import tempfile
from pathlib import Path
from datetime import datetime, timezone, timedelta
import random

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from azure.identity import AzureCliCredential
from azure.storage.blob import BlobServiceClient, ContentSettings

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(message)s")

# ─── Config ───────────────────────────────────────────────────────────────────
ADLS_ACCOUNT   = os.getenv("ADLS_ACCOUNT",   "YOUR_ADLS_ACCOUNT_NAME")
RAW_CONTAINER  = os.getenv("RAW_CONTAINER",  "raw-zone")
RAW_BASE       = os.getenv("RAW_BASE",       "tpcds/tables")
LOCAL_DB       = Path("./data/onprem_sim.db")
LOCAL_PARQUET  = Path("./data/extracts")
SOURCE_SYSTEM  = "onprem-sql-sim-v1"
ENV            = "poc"

# Small row counts for POC — scale up for load testing
TABLE_SIZES = {
    "customer":              5_000,
    "customer_address":      5_000,
    "item":                  2_000,
    "store":                   50,
    "date_dim":              5_000,
    "store_sales":          50_000,   # fact — incremental
    "catalog_sales":        30_000,   # fact — incremental
    "web_sales":            20_000,   # fact — incremental
    "store_returns":         5_000,   # fact — incremental
}

# Dimension tables → full extract each run
# Fact tables → incremental (watermark-based)
DIMENSION_TABLES = ["customer", "customer_address", "item", "store", "date_dim"]
FACT_TABLES      = ["store_sales", "catalog_sales", "web_sales", "store_returns"]


# ══════════════════════════════════════════════════════════════════════════════
# 1. ON-PREM SIMULATION — SQLite database
# ══════════════════════════════════════════════════════════════════════════════

def create_onprem_db():
    """Create SQLite database simulating an on-premises SQL Server."""
    LOCAL_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(LOCAL_DB)
    cur  = conn.cursor()

    log.info("Creating on-prem simulation database: %s", LOCAL_DB)

    cur.executescript("""
    CREATE TABLE IF NOT EXISTS customer (
        c_customer_sk     INTEGER PRIMARY KEY,
        c_customer_id     TEXT,
        c_first_name      TEXT,
        c_last_name       TEXT,
        c_email_address   TEXT,
        c_birth_year      INTEGER,
        c_preferred_flag  TEXT,
        c_current_addr_sk INTEGER,
        created_at        TEXT,
        modified_at       TEXT
    );
    CREATE TABLE IF NOT EXISTS customer_address (
        ca_address_sk  INTEGER PRIMARY KEY,
        ca_address_id  TEXT,
        ca_street_name TEXT,
        ca_city        TEXT,
        ca_state       TEXT,
        ca_zip         TEXT,
        ca_country     TEXT,
        modified_at    TEXT
    );
    CREATE TABLE IF NOT EXISTS item (
        i_item_sk       INTEGER PRIMARY KEY,
        i_item_id       TEXT,
        i_product_name  TEXT,
        i_category      TEXT,
        i_brand         TEXT,
        i_class         TEXT,
        i_current_price REAL,
        i_wholesale_cost REAL,
        modified_at     TEXT
    );
    CREATE TABLE IF NOT EXISTS store (
        s_store_sk    INTEGER PRIMARY KEY,
        s_store_id    TEXT,
        s_store_name  TEXT,
        s_city        TEXT,
        s_state       TEXT,
        modified_at   TEXT
    );
    CREATE TABLE IF NOT EXISTS date_dim (
        d_date_sk    INTEGER PRIMARY KEY,
        d_date_id    TEXT,
        d_date       TEXT,
        d_year       INTEGER,
        d_moy        INTEGER,
        d_dom        INTEGER,
        d_qoy        INTEGER,
        d_day_name   TEXT,
        modified_at  TEXT
    );
    CREATE TABLE IF NOT EXISTS store_sales (
        ss_sold_date_sk   INTEGER,
        ss_item_sk        INTEGER,
        ss_customer_sk    INTEGER,
        ss_store_sk       INTEGER,
        ss_ticket_number  INTEGER,
        ss_quantity       INTEGER,
        ss_sales_price    REAL,
        ss_list_price     REAL,
        ss_net_profit     REAL,
        modified_at       TEXT,
        _operation        TEXT DEFAULT 'I',
        PRIMARY KEY (ss_ticket_number, ss_item_sk)
    );
    CREATE TABLE IF NOT EXISTS catalog_sales (
        cs_sold_date_sk  INTEGER,
        cs_item_sk       INTEGER,
        cs_bill_customer_sk INTEGER,
        cs_order_number  INTEGER,
        cs_quantity      INTEGER,
        cs_sales_price   REAL,
        cs_net_profit    REAL,
        modified_at      TEXT,
        _operation       TEXT DEFAULT 'I',
        PRIMARY KEY (cs_order_number, cs_item_sk)
    );
    CREATE TABLE IF NOT EXISTS web_sales (
        ws_sold_date_sk  INTEGER,
        ws_item_sk       INTEGER,
        ws_bill_customer_sk INTEGER,
        ws_order_number  INTEGER,
        ws_quantity      INTEGER,
        ws_sales_price   REAL,
        ws_net_profit    REAL,
        modified_at      TEXT,
        _operation       TEXT DEFAULT 'I',
        PRIMARY KEY (ws_order_number, ws_item_sk)
    );
    CREATE TABLE IF NOT EXISTS store_returns (
        sr_returned_date_sk INTEGER,
        sr_item_sk          INTEGER,
        sr_customer_sk      INTEGER,
        sr_ticket_number    INTEGER,
        sr_return_quantity  INTEGER,
        sr_return_amt       REAL,
        modified_at         TEXT,
        _operation          TEXT DEFAULT 'I',
        PRIMARY KEY (sr_ticket_number, sr_item_sk)
    );
    CREATE TABLE IF NOT EXISTS _watermarks (
        table_name    TEXT PRIMARY KEY,
        last_extracted TEXT,
        row_count     INTEGER
    );
    """)
    conn.commit()
    return conn


def populate_onprem_db(conn: sqlite3.Connection, scale: int = 1):
    """Populate SQLite with synthetic TPC-DS-style data."""
    cur  = conn.cursor()
    now  = datetime.now(timezone.utc).isoformat()
    rng  = random.Random(42)

    log.info("Populating on-prem simulation data (scale=%d)...", scale)

    categories = ["Electronics", "Clothing", "Sports", "Books", "Home", "Food", "Toys"]
    brands     = ["BrandA", "BrandB", "BrandC", "BrandD", "BrandE"]
    states     = ["CA", "NY", "TX", "FL", "WA", "UK", "GA", "IL"]
    cities     = ["London", "Manchester", "Leeds", "Birmingham", "Bristol"]
    day_names  = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]

    # Dimensions
    n_cust = TABLE_SIZES["customer"] * scale
    customers = [
        (i, f"CUST{i:08d}", f"First{i%100}", f"Last{i%200}",
         f"user{i}@example.com", rng.randint(1950,2000), rng.choice(["Y","N"]),
         rng.randint(1, n_cust//2), now, now)
        for i in range(1, n_cust+1)
    ]
    cur.executemany("INSERT OR IGNORE INTO customer VALUES (?,?,?,?,?,?,?,?,?,?)", customers)

    n_addr = TABLE_SIZES["customer_address"] * scale
    addresses = [
        (i, f"ADDR{i:08d}", f"{rng.randint(1,999)} Main St",
         rng.choice(cities), rng.choice(states), f"{rng.randint(10000,99999)}",
         "United States", now)
        for i in range(1, n_addr+1)
    ]
    cur.executemany("INSERT OR IGNORE INTO customer_address VALUES (?,?,?,?,?,?,?,?)", addresses)

    n_item = TABLE_SIZES["item"] * scale
    items = [
        (i, f"ITEM{i:08d}", f"Product {i}", rng.choice(categories),
         rng.choice(brands), f"Class{i%10}",
         round(rng.uniform(5, 500), 2), round(rng.uniform(2, 200), 2), now)
        for i in range(1, n_item+1)
    ]
    cur.executemany("INSERT OR IGNORE INTO item VALUES (?,?,?,?,?,?,?,?,?)", items)

    n_store = TABLE_SIZES["store"] * scale
    stores = [
        (i, f"STORE{i:04d}", f"Store {i}", rng.choice(cities), rng.choice(states), now)
        for i in range(1, n_store+1)
    ]
    cur.executemany("INSERT OR IGNORE INTO store VALUES (?,?,?,?,?,?)", stores)

    # Date dim: 5 years
    date_rows = []
    base = datetime(2000, 1, 1)
    for d in range(TABLE_SIZES["date_dim"]):
        dt = base + timedelta(days=d)
        date_rows.append((
            d+1, f"D{d+1:08d}", dt.strftime("%Y-%m-%d"),
            dt.year, dt.month, dt.day, (dt.month-1)//3+1,
            day_names[dt.weekday()], now
        ))
    cur.executemany("INSERT OR IGNORE INTO date_dim VALUES (?,?,?,?,?,?,?,?,?)", date_rows)

    # Facts
    n_ss = TABLE_SIZES["store_sales"] * scale
    ss_rows = [
        (rng.randint(1,5000), rng.randint(1,n_item), rng.randint(1,n_cust),
         rng.randint(1,n_store), i, rng.randint(1,10),
         round(rng.uniform(5,500),2), round(rng.uniform(5,600),2),
         round(rng.uniform(-50,200),2), now, "I")
        for i in range(1, n_ss+1)
    ]
    cur.executemany("INSERT OR IGNORE INTO store_sales VALUES (?,?,?,?,?,?,?,?,?,?,?)", ss_rows)

    n_cs = TABLE_SIZES["catalog_sales"] * scale
    cs_rows = [
        (rng.randint(1,5000), rng.randint(1,n_item), rng.randint(1,n_cust),
         i, rng.randint(1,5), round(rng.uniform(5,500),2),
         round(rng.uniform(-50,200),2), now, "I")
        for i in range(1, n_cs+1)
    ]
    cur.executemany("INSERT OR IGNORE INTO catalog_sales VALUES (?,?,?,?,?,?,?,?,?)", cs_rows)

    n_ws = TABLE_SIZES["web_sales"] * scale
    ws_rows = [
        (rng.randint(1,5000), rng.randint(1,n_item), rng.randint(1,n_cust),
         i, rng.randint(1,5), round(rng.uniform(5,500),2),
         round(rng.uniform(-50,200),2), now, "I")
        for i in range(1, n_ws+1)
    ]
    cur.executemany("INSERT OR IGNORE INTO web_sales VALUES (?,?,?,?,?,?,?,?,?)", ws_rows)

    n_sr = TABLE_SIZES["store_returns"] * scale
    sr_rows = [
        (rng.randint(1,5000), rng.randint(1,n_item), rng.randint(1,n_cust),
         rng.randint(1,n_ss), rng.randint(1,5), round(rng.uniform(5,200),2), now, "I")
        for i in range(1, n_sr+1)
    ]
    cur.executemany("INSERT OR IGNORE INTO store_returns VALUES (?,?,?,?,?,?,?,?)", sr_rows)

    conn.commit()
    log.info("✓ On-prem database populated")


def generate_delta(conn: sqlite3.Connection):
    """Simulate new CDC delta: new inserts + some updates + some deletes."""
    cur = conn.cursor()
    now = datetime.now(timezone.utc).isoformat()
    rng = random.Random(int(time.time()))

    # New inserts
    new_ss = rng.randint(100, 500)
    max_sk = conn.execute("SELECT MAX(ss_ticket_number) FROM store_sales").fetchone()[0] or 0
    n_item = TABLE_SIZES["item"]
    n_cust = TABLE_SIZES["customer"]
    n_store = TABLE_SIZES["store"]

    for i in range(max_sk+1, max_sk+new_ss+1):
        cur.execute("""
            INSERT OR IGNORE INTO store_sales VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (rng.randint(1,5000), rng.randint(1,n_item), rng.randint(1,n_cust),
              rng.randint(1,n_store), i, rng.randint(1,10),
              round(rng.uniform(5,500),2), round(rng.uniform(5,600),2),
              round(rng.uniform(-50,200),2), now, "I"))

    # Updates (mark 50 rows as 'U')
    cur.execute("""
        UPDATE store_sales SET modified_at=?, _operation='U'
        WHERE ss_ticket_number IN (
            SELECT ss_ticket_number FROM store_sales ORDER BY RANDOM() LIMIT 50
        )
    """, (now,))

    # Deletes (mark 10 rows as 'D')
    cur.execute("""
        UPDATE store_sales SET modified_at=?, _operation='D'
        WHERE ss_ticket_number IN (
            SELECT ss_ticket_number FROM store_sales ORDER BY RANDOM() LIMIT 10
        )
    """, (now,))

    conn.commit()
    log.info("✓ Delta generated: %d inserts, ~50 updates, ~10 deletes in store_sales", new_ss)


# ══════════════════════════════════════════════════════════════════════════════
# 2. EXTRACTION — Full + Incremental
# ══════════════════════════════════════════════════════════════════════════════

def schema_hash(df: pd.DataFrame) -> str:
    schema_str = "|".join(f"{c}:{t}" for c, t in zip(df.columns, df.dtypes))
    return hashlib.sha256(schema_str.encode()).hexdigest()[:16]


def extract_full(conn: sqlite3.Connection, table: str) -> pd.DataFrame:
    """Full extract of a dimension table."""
    df = pd.read_sql_query(f"SELECT * FROM {table}", conn)
    log.info("  Full extract  %-22s  %8d rows", table, len(df))
    return df


def get_watermark(conn: sqlite3.Connection, table: str) -> str:
    """Get last extracted timestamp for incremental load."""
    row = conn.execute(
        "SELECT last_extracted FROM _watermarks WHERE table_name=?", (table,)
    ).fetchone()
    # Default: 2000-01-01 (extract everything on first run)
    return row[0] if row else "2000-01-01T00:00:00+00:00"


def set_watermark(conn: sqlite3.Connection, table: str, ts: str, rows: int):
    conn.execute("""
        INSERT INTO _watermarks (table_name, last_extracted, row_count)
        VALUES (?,?,?)
        ON CONFLICT(table_name) DO UPDATE SET last_extracted=excluded.last_extracted, row_count=excluded.row_count
    """, (table, ts, rows))
    conn.commit()


def extract_incremental(conn: sqlite3.Connection, table: str) -> pd.DataFrame:
    """
    Incremental extract: only rows with modified_at > last watermark.
    Includes CDC operation column (I/U/D).
    """
    watermark = get_watermark(conn, table)
    df = pd.read_sql_query(
        f"SELECT * FROM {table} WHERE modified_at > ?",
        conn, params=(watermark,)
    )
    log.info("  Incremental   %-22s  %8d rows  (watermark: %s)",
             table, len(df), watermark[:19])
    return df


def save_parquet(df: pd.DataFrame, table: str, mode: str) -> Path:
    """Save DataFrame as parquet with correct schema."""
    out_dir = LOCAL_PARQUET / table
    out_dir.mkdir(parents=True, exist_ok=True)
    ts   = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    path = out_dir / f"{table}_{mode}_{ts}.parquet"

    table_pa = pa.Table.from_pandas(df)
    pq.write_table(table_pa, path, compression="snappy")
    log.info("    → saved: %s  (%.1f KB)", path.name, path.stat().st_size/1024)
    return path


# ══════════════════════════════════════════════════════════════════════════════
# 3. UPLOAD — ADLS with lineage tags + manifest + SHA-256 checksum
# ══════════════════════════════════════════════════════════════════════════════

def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def adls_client() -> BlobServiceClient:
    cred = AzureCliCredential()
    return BlobServiceClient(
        account_url=f"https://{ADLS_ACCOUNT}.blob.core.windows.net",
        credential=cred,
    )


def upload_file(client: BlobServiceClient, local_path: Path, table: str,
                mode: str, schema_ver: str, row_count: int) -> dict:
    """
    Upload parquet file to ADLS raw-zone with lineage metadata tags.

    Blob path: raw-zone/tpcds/tables/{table}/{filename}
    Blob tags (lineage provenance):
      source_system, extract_mode, extract_ts, schema_version, row_count, env, checksum
    """
    blob_name = f"{RAW_BASE}/{table}/{local_path.name}"
    checksum  = file_sha256(local_path)
    extract_ts = datetime.now(timezone.utc).isoformat()

    # Blob index tags (searchable metadata — lineage provenance)
    tags = {
        "source_system":   SOURCE_SYSTEM,
        "source_table":    table,
        "extract_mode":    mode,            # full / incremental
        "schema_version":  schema_ver,
        "row_count":       str(row_count),
        "environment":     ENV,
        "data_mesh_plane": "platform",
        "extract_ts":      extract_ts[:19].replace(":", "-"),
    }

    blob_client = client.get_blob_client(container=RAW_CONTAINER, blob=blob_name)

    for attempt in range(3):
        try:
            with open(local_path, "rb") as f:
                blob_client.upload_blob(
                    f, overwrite=True,
                    content_settings=ContentSettings(content_type="application/octet-stream"),
                    tags=tags,
                )
            # Verify checksum post-upload
            props = blob_client.get_blob_properties()
            uploaded_size = props.size
            assert uploaded_size == local_path.stat().st_size, \
                f"Size mismatch: local={local_path.stat().st_size} adls={uploaded_size}"

            log.info("    ✓ Uploaded: %s  (%d bytes)", blob_name, uploaded_size)
            return {
                "table":          table,
                "blob_path":      blob_name,
                "mode":           mode,
                "schema_version": schema_ver,
                "row_count":      row_count,
                "size_bytes":     uploaded_size,
                "checksum_sha256":checksum,
                "tags":           tags,
                "extract_ts":     extract_ts,
                "status":         "success",
            }
        except Exception as e:
            wait = 2 ** attempt
            log.warning("  Upload attempt %d failed: %s — retry in %ds", attempt+1, e, wait)
            time.sleep(wait)

    raise RuntimeError(f"Upload failed after 3 attempts: {table}")


def write_manifest(client: BlobServiceClient, run_id: str, records: list):
    """Write upload manifest to raw-zone/_manifests/{date}/{run_id}.json"""
    date_str   = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    blob_name  = f"_manifests/{date_str}/{run_id}.json"
    manifest   = {
        "run_id":      run_id,
        "source":      SOURCE_SYSTEM,
        "environment": ENV,
        "created_at":  datetime.now(timezone.utc).isoformat(),
        "tables":      records,
        "summary": {
            "total_tables": len(records),
            "total_rows":   sum(r["row_count"] for r in records),
            "total_bytes":  sum(r["size_bytes"] for r in records),
            "failed":       sum(1 for r in records if r.get("status") != "success"),
        }
    }
    client.get_blob_client(container=RAW_CONTAINER, blob=blob_name).upload_blob(
        json.dumps(manifest, indent=2).encode(), overwrite=True
    )
    log.info("✓ Manifest written: %s", blob_name)
    return manifest


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="On-prem simulation → ADLS upload POC")
    parser.add_argument("--mode",           default="full",
                        choices=["full","incremental","both"])
    parser.add_argument("--generate-delta", action="store_true",
                        help="Inject new CDC delta into on-prem DB before extract")
    parser.add_argument("--dry-run",        action="store_true",
                        help="Extract only — do not upload to ADLS")
    parser.add_argument("--scale",          type=int, default=1,
                        help="Data scale multiplier (default 1 = ~5k customers)")
    args = parser.parse_args()

    run_id = f"ingest-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
    log.info("=" * 60)
    log.info("  ON-PREM → ADLS Ingestion POC")
    log.info("  Run ID   : %s", run_id)
    log.info("  Mode     : %s", args.mode)
    log.info("  Dry run  : %s", args.dry_run)
    log.info("  ADLS     : %s/%s", ADLS_ACCOUNT, RAW_CONTAINER)
    log.info("=" * 60)

    # Step 1: Ensure on-prem DB exists and is populated
    conn = create_onprem_db()
    row = conn.execute("SELECT COUNT(*) FROM customer").fetchone()[0]
    if row == 0:
        populate_onprem_db(conn, scale=args.scale)

    # Step 2: Optionally inject CDC delta
    if args.generate_delta:
        generate_delta(conn)

    # Step 3: Extract
    LOCAL_PARQUET.mkdir(parents=True, exist_ok=True)
    extracts = []

    if args.mode in ("full", "both"):
        log.info("\n── Full extract (dimension tables) ──")
        for table in DIMENSION_TABLES:
            df   = extract_full(conn, table)
            path = save_parquet(df, table, "full")
            extracts.append(("full", table, df, path, schema_hash(df)))

    if args.mode in ("incremental", "both"):
        log.info("\n── Incremental extract (fact tables) ──")
        for table in FACT_TABLES:
            df   = extract_incremental(conn, table)
            if len(df) == 0:
                log.info("  No new rows for %s — skipping", table)
                continue
            path = save_parquet(df, table, "incremental")
            extracts.append(("incremental", table, df, path, schema_hash(df)))
            # Update watermark only after successful save
            wm = datetime.now(timezone.utc).isoformat()
            set_watermark(conn, table, wm, len(df))
            log.info("  Watermark updated: %s → %s", table, wm[:19])

    log.info("\n── Extract summary: %d files ──", len(extracts))
    for mode, table, df, path, shash in extracts:
        log.info("  %-12s %-25s %7d rows  schema=%s", mode, table, len(df), shash)

    if args.dry_run:
        log.info("\n✓ Dry run complete — no upload to ADLS")
        return

    # Step 4: Upload to ADLS
    log.info("\n── Uploading to ADLS %s/%s ──", ADLS_ACCOUNT, RAW_CONTAINER)
    client  = adls_client()
    records = []
    for mode, table, df, path, shash in extracts:
        rec = upload_file(client, path, table, mode, shash, len(df))
        records.append(rec)

    # Step 5: Write manifest
    manifest = write_manifest(client, run_id, records)

    log.info("\n" + "=" * 60)
    log.info("✅ Ingestion complete")
    log.info("   Run ID        : %s", run_id)
    log.info("   Tables loaded : %d", manifest["summary"]["total_tables"])
    log.info("   Total rows    : %d", manifest["summary"]["total_rows"])
    log.info("   Total bytes   : %.1f MB", manifest["summary"]["total_bytes"]/1e6)
    log.info("   Failed        : %d", manifest["summary"]["failed"])
    log.info("   Manifest      : _manifests/%s/%s.json",
             datetime.now(timezone.utc).strftime("%Y-%m-%d"), run_id)
    log.info("=" * 60)

    if manifest["summary"]["failed"] > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
