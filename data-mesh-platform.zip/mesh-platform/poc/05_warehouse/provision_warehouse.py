"""
poc/05_warehouse/provision_warehouse.py
========================================
JIRA: DE-3 — Fabric Warehouse provision and load gold models via SQL

Data Mesh Plane: Data Product Plane
Owner: Data Engineering / Domain Teams

Demonstrates:
  - Fabric Warehouse provisioning via REST API
  - Shortcut from Warehouse → ADLS gold Iceberg tables
  - CTAS (CREATE TABLE AS SELECT) to materialise gold models in Warehouse
  - MERGE INTO pattern for incremental refresh
  - Row counts parity test: Warehouse == Iceberg source
  - JDBC/ODBC connection string extraction for BI tool connectivity

Run:
    python poc/05_warehouse/provision_warehouse.py --provision
    python poc/05_warehouse/provision_warehouse.py --load
    python poc/05_warehouse/provision_warehouse.py --validate
    python poc/05_warehouse/provision_warehouse.py --connection-string
"""

import sys
import json
import time
import logging
import argparse
import requests
from pathlib import Path
from datetime import datetime, timezone

import yaml
from azure.identity import AzureCliCredential

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(message)s")

ROOT = Path(__file__).resolve().parents[2]
CFG  = yaml.safe_load((ROOT / "config.yaml").read_text()) if (ROOT / "config.yaml").exists() else {}

WORKSPACE_ID  = CFG.get("fabric",{}).get("workspace_id",  "YOUR_WORKSPACE_ID")
LAKEHOUSE_ID  = CFG.get("fabric",{}).get("lakehouse_id",  "YOUR_LAKEHOUSE_ID")
ADLS_ACCOUNT  = CFG.get("adls",  {}).get("account_name",  "YOUR_ADLS_ACCOUNT")
ADLS_CONTAINER= CFG.get("adls",  {}).get("prepared_container", "prepared-zone")
GOLD_BASE     = CFG.get("adls",  {}).get("gold_base_path",     "tpcds/gold")
CONN_ID       = CFG.get("adls",  {}).get("prepared_connection_id", "YOUR_CONN_ID")

WAREHOUSE_NAME = "tpcds_warehouse"
FABRIC_API     = "https://api.fabric.microsoft.com/v1"

GOLD_TABLES = [
    "gold_sales_fact",
    "gold_customer_360",
    "gold_product_performance",
]


# ─── Auth ─────────────────────────────────────────────────────────────────────

def fabric_headers() -> dict:
    token = AzureCliCredential().get_token("https://api.fabric.microsoft.com/.default")
    return {"Authorization": f"Bearer {token.token}", "Content-Type": "application/json"}


# ══════════════════════════════════════════════════════════════════════════════
# WAREHOUSE PROVISIONING
# ══════════════════════════════════════════════════════════════════════════════

def provision_warehouse() -> dict:
    """Create Fabric Warehouse item in the workspace."""
    log.info("Provisioning Fabric Warehouse: %s", WAREHOUSE_NAME)

    # Check if already exists
    resp = requests.get(
        f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/warehouses",
        headers=fabric_headers(), timeout=30
    )
    if resp.status_code == 200:
        for item in resp.json().get("value", []):
            if item["displayName"] == WAREHOUSE_NAME:
                log.info("  ✓ Warehouse already exists: %s", item["id"])
                return item

    # Create
    resp = requests.post(
        f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/warehouses",
        json={
            "displayName": WAREHOUSE_NAME,
            "description": "TPC-DS gold models — SQL access layer for BI tools",
        },
        headers=fabric_headers(), timeout=60
    )
    if resp.status_code not in (200, 201, 202):
        log.error("Warehouse creation failed: %s — %s", resp.status_code, resp.text[:300])
        resp.raise_for_status()

    # Poll for completion if async
    if resp.status_code == 202:
        location = resp.headers.get("Location", "")
        for _ in range(30):
            time.sleep(10)
            poll = requests.get(location, headers=fabric_headers(), timeout=30)
            if poll.status_code == 200:
                result = poll.json()
                if result.get("status") in ("Succeeded", "succeeded"):
                    warehouse = result.get("createdItemId") or result
                    log.info("  ✓ Warehouse created")
                    return warehouse
    else:
        log.info("  ✓ Warehouse created: %s", resp.json().get("id"))
        return resp.json()


def get_warehouse_id() -> str | None:
    resp = requests.get(
        f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/warehouses",
        headers=fabric_headers(), timeout=30
    )
    if resp.status_code == 200:
        for item in resp.json().get("value", []):
            if item["displayName"] == WAREHOUSE_NAME:
                return item["id"]
    return None


# ══════════════════════════════════════════════════════════════════════════════
# SHORTCUTS — Warehouse → ADLS gold Iceberg
# ══════════════════════════════════════════════════════════════════════════════

def create_warehouse_shortcuts(warehouse_id: str):
    """
    Register shortcuts in the Warehouse pointing to ADLS gold Iceberg tables.
    This gives the Warehouse T-SQL engine visibility into the Iceberg data.
    """
    log.info("Creating Warehouse shortcuts → ADLS gold Iceberg tables")
    shortcuts_api = f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/items/{warehouse_id}/shortcuts"

    for table in GOLD_TABLES:
        payload = {
            "path":   "Tables",
            "name":   table,
            "target": {
                "type": "adlsGen2",
                "adlsGen2": {
                    "location":     f"https://{ADLS_ACCOUNT}.dfs.core.windows.net",
                    "subpath":      f"/{ADLS_CONTAINER}/{GOLD_BASE}/{table}",
                    "connectionId": CONN_ID,
                }
            }
        }
        resp = requests.post(shortcuts_api, json=payload, headers=fabric_headers(), timeout=30)
        if resp.status_code in (200, 201):
            log.info("  ✓ Shortcut: Tables/%s → ADLS %s/%s", table, GOLD_BASE, table)
        elif resp.status_code == 409:
            log.info("  ↷ Shortcut already exists: %s", table)
        else:
            log.warning("  ✗ Shortcut failed for %s: %d — %s", table, resp.status_code, resp.text[:200])
        time.sleep(0.5)


# ══════════════════════════════════════════════════════════════════════════════
# SQL EXECUTION via Warehouse endpoint
# Fabric Warehouse exposes a TDS (SQL Server) endpoint — use pyodbc or
# the Fabric SQL API (preview) for programmatic execution.
# Below uses the Fabric SQL statements API (REST-based, no ODBC driver needed).
# ══════════════════════════════════════════════════════════════════════════════

def execute_sql(warehouse_id: str, sql: str) -> dict:
    """
    Execute T-SQL statement via Fabric Warehouse REST API.
    NOTE: Fabric SQL Statements API is in preview — check docs for GA status.
    """
    url  = f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/warehouses/{warehouse_id}/sqlStatements"
    resp = requests.post(url, json={"statement": sql}, headers=fabric_headers(), timeout=120)
    if resp.status_code not in (200, 201, 202):
        log.error("SQL execution failed (%d): %s", resp.status_code, resp.text[:400])
        return {"status": "error", "error": resp.text}
    return resp.json()


def load_gold_to_warehouse(warehouse_id: str):
    """
    Materialise gold Iceberg shortcuts into native Warehouse tables.
    Uses CTAS (CREATE TABLE AS SELECT) from the shortcut views.
    """
    log.info("Loading gold models into Warehouse (CTAS)...")

    # Ensure schema exists
    execute_sql(warehouse_id, "CREATE SCHEMA IF NOT EXISTS gold")

    for table in GOLD_TABLES:
        log.info("  Loading: %s", table)
        # Drop + CTAS for full refresh
        execute_sql(warehouse_id, f"DROP TABLE IF EXISTS gold.{table}")
        result = execute_sql(warehouse_id, f"""
            CREATE TABLE gold.{table}
            AS SELECT * FROM Tables.{table}
        """)
        status = result.get("status", "unknown")
        log.info("    %s → %s", table, status)
        time.sleep(1)


def merge_incremental(warehouse_id: str, table: str, pk_columns: list[str]):
    """
    MERGE INTO pattern for incremental refresh of a Warehouse table.
    pk_columns: list of primary key column names to match on.
    """
    match_clause = " AND ".join(f"target.{c} = source.{c}" for c in pk_columns)
    non_pk = [c for c in ["channel","sold_date_sk","item_sk","customer_sk","gross_sales_amt",
                           "net_sales_amt","quantity","return_amt"] if c not in pk_columns]
    update_clause = ", ".join(f"target.{c} = source.{c}" for c in non_pk[:5])
    insert_cols   = ", ".join(pk_columns + non_pk[:5])
    insert_vals   = ", ".join(f"source.{c}" for c in pk_columns + non_pk[:5])

    sql = f"""
        MERGE INTO gold.{table} AS target
        USING Tables.{table} AS source
        ON ({match_clause})
        WHEN MATCHED THEN UPDATE SET {update_clause}
        WHEN NOT MATCHED THEN INSERT ({insert_cols}) VALUES ({insert_vals});
    """
    log.info("  MERGE INTO %s on %s", table, pk_columns)
    return execute_sql(warehouse_id, sql)


# ══════════════════════════════════════════════════════════════════════════════
# VALIDATION — row count parity
# ══════════════════════════════════════════════════════════════════════════════

def validate_row_counts(warehouse_id: str) -> bool:
    """
    Validate Warehouse row counts match the Iceberg shortcut counts.
    Passes if counts are within 0.1% tolerance.
    """
    log.info("Validating row count parity: Warehouse vs Iceberg shortcuts")
    all_pass = True

    for table in GOLD_TABLES:
        # Warehouse count
        wh_result = execute_sql(warehouse_id, f"SELECT COUNT(*) AS cnt FROM gold.{table}")
        wh_count = wh_result.get("results", [{}])[0].get("cnt", -1)

        # Shortcut (Iceberg) count
        ic_result = execute_sql(warehouse_id, f"SELECT COUNT(*) AS cnt FROM Tables.{table}")
        ic_count = ic_result.get("results", [{}])[0].get("cnt", -2)

        if wh_count < 0 or ic_count < 0:
            log.warning("  ⚠  %-35s  could not read counts", table)
            continue

        diff_pct = abs(wh_count - ic_count) / max(ic_count, 1) * 100
        ok = diff_pct < 0.1
        status = "✓" if ok else "✗"
        log.info("  %s  %-35s  Warehouse=%s  Iceberg=%s  diff=%.3f%%",
                 status, table, f"{wh_count:,}", f"{ic_count:,}", diff_pct)
        if not ok:
            all_pass = False

    return all_pass


# ══════════════════════════════════════════════════════════════════════════════
# CONNECTION STRING — for BI tools (Tableau, Excel, Power BI XMLA)
# ══════════════════════════════════════════════════════════════════════════════

def get_connection_info(warehouse_id: str) -> dict:
    """
    Extract Warehouse connection details for external BI tools.
    Returns JDBC, ODBC, and ADO.NET connection strings.
    """
    resp = requests.get(
        f"{FABRIC_API}/workspaces/{WORKSPACE_ID}/warehouses/{warehouse_id}",
        headers=fabric_headers(), timeout=30
    )
    if resp.status_code != 200:
        return {}

    props = resp.json().get("properties", {})
    server = props.get("connectionString", f"{warehouse_id}.warehouse.fabric.microsoft.com")

    return {
        "server":      server,
        "database":    WAREHOUSE_NAME,
        "jdbc":        f"jdbc:sqlserver://{server};database={WAREHOUSE_NAME};authentication=ActiveDirectoryInteractive",
        "odbc":        f"Driver={{ODBC Driver 18 for SQL Server}};Server={server};Database={WAREHOUSE_NAME};Authentication=ActiveDirectoryInteractive",
        "ado_net":     f"Server={server};Database={WAREHOUSE_NAME};Authentication=Active Directory Interactive",
        "powerbi":     f"powerbi://api.powerbi.com/v1.0/myorg/{WORKSPACE_ID}",
        "note":        "Use Azure AD / Entra ID authentication. No username/password.",
    }


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Fabric Warehouse provisioning and ETL")
    parser.add_argument("--provision",        action="store_true", help="Create Warehouse + shortcuts")
    parser.add_argument("--load",             action="store_true", help="CTAS gold models into Warehouse")
    parser.add_argument("--merge",            action="store_true", help="MERGE incremental for sales_fact")
    parser.add_argument("--validate",         action="store_true", help="Row count parity check")
    parser.add_argument("--connection-string",action="store_true", help="Print connection strings")
    parser.add_argument("--all",              action="store_true", help="Run all steps")
    args = parser.parse_args()

    warehouse_id = get_warehouse_id()

    if args.provision or args.all:
        result = provision_warehouse()
        warehouse_id = get_warehouse_id()
        if warehouse_id:
            create_warehouse_shortcuts(warehouse_id)
            log.info("✓ Warehouse provisioned and shortcuts registered")

    if not warehouse_id:
        log.error("Warehouse not found — run --provision first")
        sys.exit(1)

    if args.load or args.all:
        load_gold_to_warehouse(warehouse_id)
        log.info("✓ Gold models loaded")

    if args.merge:
        merge_incremental(warehouse_id, "gold_sales_fact",
                          ["channel", "transaction_id", "item_sk"])

    if args.validate or args.all:
        ok = validate_row_counts(warehouse_id)
        if ok:
            log.info("✓ Row count validation passed")
        else:
            log.error("✗ Row count parity check failed")
            sys.exit(1)

    if args.connection_string or args.all:
        info = get_connection_info(warehouse_id)
        print("\n── Warehouse Connection Strings ──")
        for k, v in info.items():
            print(f"  {k:12s}: {v}")

    if not any([args.provision, args.load, args.merge, args.validate,
                args.connection_string, args.all]):
        parser.print_help()


if __name__ == "__main__":
    main()
