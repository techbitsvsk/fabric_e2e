"""
poc/03_event_pipeline/trigger_fabric_job.py
============================================
JIRA: EVENT-1 — Event Grid subscription on ADLS blob created events
JIRA: EVENT-2 — Service Bus consumer triggers Fabric CopyJob or Notebook
JIRA: EVENT-3 — Coordination pattern for silver trigger

Data Mesh Plane: Data Platform Plane
Owner: Data Platform Engineering Team

Architecture:
  ADLS blob created
    → Event Grid (BlobCreated filter: tpcds/tables/)
    → Service Bus topic: tpcds-raw-ingest
    → THIS CONSUMER:
        parse event → determine table → route to CopyJob or Notebook
        → poll Fabric job until terminal → complete/abandon message
        → write audit to Log Analytics

Run:
    # Full setup: Event Grid + Service Bus + start consumer
    python poc/03_event_pipeline/trigger_fabric_job.py --setup

    # Start consumer only (infrastructure already created)
    python poc/03_event_pipeline/trigger_fabric_job.py --consume

    # Test: simulate a blob event without real ADLS trigger
    python poc/03_event_pipeline/trigger_fabric_job.py --test-event customer

    # Show coordination state (silver readiness)
    python poc/03_event_pipeline/trigger_fabric_job.py --show-state
"""

import os
import sys
import json
import time
import logging
import argparse
import hashlib
from datetime import datetime, timezone
from pathlib import Path

import requests
import yaml
from azure.identity import AzureCliCredential
from azure.servicebus import ServiceBusClient, ServiceBusMessage
from azure.servicebus.management import ServiceBusAdministrationClient

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(message)s")

ROOT = Path(__file__).resolve().parents[2]
CFG  = yaml.safe_load((ROOT / "config.yaml").read_text()) if (ROOT / "config.yaml").exists() else {}

# ─── Config ───────────────────────────────────────────────────────────────────
TENANT_ID         = CFG.get("azure",{}).get("tenant_id",       "YOUR_TENANT_ID")
SUBSCRIPTION_ID   = CFG.get("azure",{}).get("subscription_id", "YOUR_SUBSCRIPTION_ID")
RESOURCE_GROUP    = CFG.get("azure",{}).get("resource_group",  "rg-fabric-platform")
LOCATION          = CFG.get("azure",{}).get("location",        "uksouth")
ADLS_ACCOUNT      = CFG.get("adls",{}).get("account_name",     "YOUR_ADLS_ACCOUNT")
ADLS_RESOURCE_ID  = (
    f"/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
    f"/providers/Microsoft.Storage/storageAccounts/{ADLS_ACCOUNT}"
)
SB_NAMESPACE      = CFG.get("event",{}).get("servicebus_namespace", "sb-fabric-platform")
SB_TOPIC          = "tpcds-raw-ingest"
SB_SUBSCRIPTION   = "fabric-trigger"
EG_TOPIC_NAME     = "eg-adls-tpcds"
RAW_BLOB_PREFIX   = "tpcds/tables/"

WORKSPACE_ID      = CFG.get("fabric",{}).get("workspace_id",  "YOUR_WORKSPACE_ID")
FABRIC_API_BASE   = "https://api.fabric.microsoft.com/v1"

# Routing: which tables go to CopyJob (simple) vs Notebook (complex)
COPYJOB_TABLES  = ["customer","customer_address","item","store","date_dim",
                   "warehouse","ship_mode","call_center","catalog_page",
                   "web_site","web_page","promotion","reason","income_band",
                   "household_demographics","customer_demographics"]
NOTEBOOK_TABLES = ["store_sales","catalog_sales","web_sales",
                   "store_returns","catalog_returns","web_returns","inventory"]

# Silver coordination: all raw tables that must arrive before silver triggers
SILVER_DEPENDENCIES = {
    "tpcds": COPYJOB_TABLES + NOTEBOOK_TABLES
}


# ─── Auth helpers ─────────────────────────────────────────────────────────────

def arm_token() -> str:
    return AzureCliCredential().get_token("https://management.azure.com/.default").token

def fabric_token() -> str:
    return AzureCliCredential().get_token("https://api.fabric.microsoft.com/.default").token

def arm_headers() -> dict:
    return {"Authorization": f"Bearer {arm_token()}", "Content-Type": "application/json"}

def fabric_headers() -> dict:
    return {"Authorization": f"Bearer {fabric_token()}", "Content-Type": "application/json"}


# ══════════════════════════════════════════════════════════════════════════════
# INFRASTRUCTURE SETUP
# ══════════════════════════════════════════════════════════════════════════════

def setup_servicebus():
    """Create Service Bus namespace, topic, subscription with dead-letter."""
    log.info("Setting up Service Bus: %s", SB_NAMESPACE)
    arm = "https://management.azure.com"
    api = "2022-10-01-preview"

    # Namespace
    ns_url = (
        f"{arm}/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.ServiceBus/namespaces/{SB_NAMESPACE}?api-version={api}"
    )
    resp = requests.put(ns_url, json={
        "location": LOCATION,
        "sku": {"name": "Standard", "tier": "Standard"},
        "properties": {},
        "tags": {"data-mesh-plane": "platform", "component": "event-pipeline"},
    }, headers=arm_headers(), timeout=60)
    if resp.status_code not in (200, 201, 202):
        log.error("SB namespace: %s — %s", resp.status_code, resp.text[:200])
    else:
        log.info("  ✓ Namespace: %s", SB_NAMESPACE)

    # Topic
    topic_url = (
        f"{arm}/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.ServiceBus/namespaces/{SB_NAMESPACE}"
        f"/topics/{SB_TOPIC}?api-version={api}"
    )
    resp = requests.put(topic_url, json={"properties": {
        "defaultMessageTimeToLive": "P1D",  # 24h TTL
        "enablePartitioning": False,
    }}, headers=arm_headers(), timeout=30)
    log.info("  ✓ Topic: %s  (%s)", SB_TOPIC, resp.status_code)

    # Subscription with dead-letter
    sub_url = (
        f"{arm}/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.ServiceBus/namespaces/{SB_NAMESPACE}"
        f"/topics/{SB_TOPIC}/subscriptions/{SB_SUBSCRIPTION}?api-version={api}"
    )
    resp = requests.put(sub_url, json={"properties": {
        "maxDeliveryCount": 3,                          # dead-letter after 3 failures
        "deadLetteringOnMessageExpiration": True,
        "lockDuration": "PT5M",                          # 5min peek-lock
        "defaultMessageTimeToLive": "P1D",
    }}, headers=arm_headers(), timeout=30)
    log.info("  ✓ Subscription: %s (maxDelivery=3, lock=5min)  (%s)", SB_SUBSCRIPTION, resp.status_code)


def setup_event_grid():
    """Create Event Grid system topic + subscription on ADLS → Service Bus."""
    log.info("Setting up Event Grid system topic: %s", EG_TOPIC_NAME)
    arm = "https://management.azure.com"
    api = "2022-06-15"

    # System topic on ADLS storage account
    st_url = (
        f"{arm}/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.EventGrid/systemTopics/{EG_TOPIC_NAME}?api-version={api}"
    )
    resp = requests.put(st_url, json={
        "location": LOCATION,
        "properties": {
            "source":    ADLS_RESOURCE_ID,
            "topicType": "Microsoft.Storage.StorageAccounts",
        },
        "tags": {"data-mesh-plane": "platform"},
    }, headers=arm_headers(), timeout=30)
    log.info("  ✓ System topic: %s  (%s)", EG_TOPIC_NAME, resp.status_code)

    # Event subscription: BlobCreated → Service Bus topic
    # Filter: only tpcds/tables/ prefix
    sb_resource_id = (
        f"/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.ServiceBus/namespaces/{SB_NAMESPACE}/topics/{SB_TOPIC}"
    )
    sub_url = (
        f"{arm}/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.EventGrid/systemTopics/{EG_TOPIC_NAME}"
        f"/eventSubscriptions/adls-blob-created?api-version={api}"
    )
    resp = requests.put(sub_url, json={"properties": {
        "destination": {
            "endpointType": "ServiceBusTopic",
            "properties":   {"resourceId": sb_resource_id},
        },
        "filter": {
            "includedEventTypes":  ["Microsoft.Storage.BlobCreated"],
            "advancedFilters": [{
                "operatorType":  "StringBeginsWith",
                "key":           "subject",
                "values":        [f"/blobServices/default/containers/raw-zone/blobs/{RAW_BLOB_PREFIX}"],
            }],
        },
        "eventDeliverySchema": "EventGridSchema",
        "retryPolicy": {"maxDeliveryAttempts": 3, "eventTimeToLiveInMinutes": 1440},
    }}, headers=arm_headers(), timeout=30)
    log.info("  ✓ Event subscription: BlobCreated → %s  (%s)", SB_TOPIC, resp.status_code)


# ══════════════════════════════════════════════════════════════════════════════
# EVENT PARSING
# ══════════════════════════════════════════════════════════════════════════════

def parse_blob_event(body: dict) -> dict | None:
    """
    Extract table name and metadata from an Event Grid blob event.
    Subject format: /blobServices/default/containers/raw-zone/blobs/tpcds/tables/{table}/file.parquet
    """
    subject = body.get("subject", "")
    data    = body.get("data", {})

    if "BlobCreated" not in body.get("eventType", ""):
        return None

    # Extract table from blob path
    # subject = ".../tpcds/tables/customer/customer_full_20240101.parquet"
    parts = subject.split(f"/blobs/{RAW_BLOB_PREFIX}")
    if len(parts) < 2:
        return None

    table_path = parts[1]
    table_name = table_path.split("/")[0]

    return {
        "table":     table_name,
        "blob_path": data.get("url", ""),
        "blob_size": data.get("contentLength", 0),
        "event_id":  body.get("id", ""),
        "event_time":body.get("eventTime", ""),
    }


def message_id(event_id: str, table: str) -> str:
    """Dedup key: hash of event_id + table."""
    return hashlib.sha256(f"{event_id}:{table}".encode()).hexdigest()[:16]


# ══════════════════════════════════════════════════════════════════════════════
# FABRIC JOB TRIGGER
# ══════════════════════════════════════════════════════════════════════════════

def load_job_ids() -> tuple[dict, dict]:
    """Load CopyJob IDs and notebook IDs from provisioning step."""
    cj_path = ROOT / "03_fabric_provisioning" / "copy_job_ids.json"
    nb_path = ROOT / "03_fabric_provisioning" / "notebook_ids.json"
    copy_jobs = json.loads(cj_path.read_text()) if cj_path.exists() else {}
    notebooks  = json.loads(nb_path.read_text())  if nb_path.exists()  else {}
    return copy_jobs, notebooks


def trigger_copyjob(table: str, copy_job_ids: dict) -> str | None:
    """Trigger a Fabric CopyJob for a simple dimension table."""
    job_id = copy_job_ids.get(table)
    if not job_id:
        log.warning("No CopyJob ID for table: %s", table)
        return None

    url  = (f"{FABRIC_API_BASE}/workspaces/{WORKSPACE_ID}"
            f"/items/{job_id}/jobs/instances?jobType=Execute")
    resp = requests.post(url, json={}, headers=fabric_headers(), timeout=60)
    if resp.status_code not in (200, 201, 202):
        log.error("CopyJob trigger failed for %s: %d", table, resp.status_code)
        return None

    location = resp.headers.get("Location", "")
    run_id   = location.rstrip("/").split("/")[-1] if location else None
    log.info("  ▶ CopyJob triggered: %-22s  run_id=%s", table, run_id)
    return run_id


def trigger_notebook(notebook_id: str, table: str) -> str | None:
    """Trigger a Fabric Notebook for a complex fact table."""
    url  = (f"{FABRIC_API_BASE}/workspaces/{WORKSPACE_ID}"
            f"/items/{notebook_id}/jobs/instances?jobType=RunNotebook")
    body = {
        "executionData": {
            "parameters": {"TABLE_NAME": {"value": table, "type": "string"}}
        }
    }
    resp = requests.post(url, json=body, headers=fabric_headers(), timeout=60)
    if resp.status_code not in (200, 201, 202):
        log.error("Notebook trigger failed for %s: %d", table, resp.status_code)
        return None

    location = resp.headers.get("Location", "")
    run_id   = location.rstrip("/").split("/")[-1] if location else None
    log.info("  ▶ Notebook triggered: %-22s  run_id=%s", table, run_id)
    return run_id


def poll_job_status(item_id: str, run_id: str, job_type: str,
                    timeout_sec: int = 3600) -> str:
    """Poll Fabric job until terminal state. Returns 'succeeded' or 'failed'."""
    endpoint = "copyJobs" if job_type == "copyjob" else "items"
    deadline = time.time() + timeout_sec
    interval = 15

    while time.time() < deadline:
        time.sleep(interval)
        try:
            url = (f"{FABRIC_API_BASE}/workspaces/{WORKSPACE_ID}"
                   f"/{endpoint}/{item_id}/jobs/instances/{run_id}")
            resp = requests.get(url, headers=fabric_headers(), timeout=30)
            if resp.status_code == 200:
                status = resp.json().get("status", "").lower()
                if status in ("succeeded", "completed"):
                    return "succeeded"
                if status in ("failed", "canceled"):
                    return "failed"
        except Exception as e:
            log.warning("  Poll error: %s", e)
        interval = min(interval * 1.3, 60)

    return "timeout"


# ══════════════════════════════════════════════════════════════════════════════
# SILVER COORDINATION
# ══════════════════════════════════════════════════════════════════════════════

# In-memory state for POC (use ADLS _control/ in production)
_silver_state: dict = {}


def mark_table_arrived(domain: str, table: str, run_date: str):
    key = f"{domain}:{run_date}"
    if key not in _silver_state:
        _silver_state[key] = {"arrived": set(), "triggered": False}
    _silver_state[key]["arrived"].add(table)
    deps = set(SILVER_DEPENDENCIES.get(domain, []))
    arrived = _silver_state[key]["arrived"]
    log.info("  Silver state [%s/%s]: %d/%d tables arrived",
             domain, run_date, len(arrived), len(deps))


def should_trigger_silver(domain: str, run_date: str) -> bool:
    key  = f"{domain}:{run_date}"
    state = _silver_state.get(key, {})
    if state.get("triggered"):
        return False
    deps    = set(SILVER_DEPENDENCIES.get(domain, []))
    arrived = state.get("arrived", set())
    ready   = deps.issubset(arrived)
    if ready:
        _silver_state[key]["triggered"] = True
        log.info("  ✓ All dependencies met for silver/%s/%s — triggering!", domain, run_date)
    return ready


# ══════════════════════════════════════════════════════════════════════════════
# CONSUMER MAIN LOOP
# ══════════════════════════════════════════════════════════════════════════════

def consume(max_messages: int = 0):
    """
    Service Bus consumer main loop.
    Reads messages, routes to CopyJob or Notebook, polls for completion,
    completes or abandons message based on outcome.
    """
    sb_conn_str = (
        f"Endpoint=sb://{SB_NAMESPACE}.servicebus.windows.net/;"
        f"Authentication=ManagedIdentity"
    )
    # For POC with AzureCliCredential:
    cred = AzureCliCredential()

    copy_jobs, notebooks = load_job_ids()
    silver_nb_id = notebooks.get("silver", "")

    log.info("Starting Service Bus consumer")
    log.info("  Namespace  : %s", SB_NAMESPACE)
    log.info("  Topic      : %s / %s", SB_TOPIC, SB_SUBSCRIPTION)
    log.info("  CopyJob IDs: %d loaded", len(copy_jobs))
    log.info("  Silver NB  : %s", silver_nb_id or "NOT CONFIGURED")

    processed = set()
    count = 0

    with ServiceBusClient(
        fully_qualified_namespace=f"{SB_NAMESPACE}.servicebus.windows.net",
        credential=cred,
    ) as sb_client:
        with sb_client.get_subscription_receiver(
            topic_name=SB_TOPIC,
            subscription_name=SB_SUBSCRIPTION,
            max_wait_time=30,
        ) as receiver:
            for msg in receiver:
                count += 1
                if max_messages and count > max_messages:
                    break

                audit = {
                    "event_id":    str(msg.message_id),
                    "received_at": datetime.now(timezone.utc).isoformat(),
                    "status":      "processing",
                }

                try:
                    body  = json.loads(str(msg))
                    event = parse_blob_event(body)

                    if not event:
                        log.warning("  Unparseable event — completing: %s", str(msg)[:100])
                        receiver.complete_message(msg)
                        continue

                    table    = event["table"]
                    dedup_id = message_id(event["event_id"], table)

                    # Dedup check
                    if dedup_id in processed:
                        log.info("  Duplicate message for %s — completing", table)
                        receiver.complete_message(msg)
                        continue
                    processed.add(dedup_id)

                    log.info("\n── Event: %s  table=%s  size=%d bytes",
                             event["event_id"][:8], table, event["blob_size"])

                    # Route: dimension → CopyJob, fact → keep in raw until silver
                    run_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

                    if table in COPYJOB_TABLES and copy_jobs:
                        run_id  = trigger_copyjob(table, copy_jobs)
                        job_id  = copy_jobs.get(table, "")
                        outcome = poll_job_status(job_id, run_id, "copyjob") if run_id else "no_id"
                    elif table in NOTEBOOK_TABLES:
                        # Raw fact table landed — track for silver coordination
                        mark_table_arrived("tpcds", table, run_date)
                        outcome = "coordinated"
                    else:
                        log.warning("  Unknown table: %s — skipping", table)
                        receiver.complete_message(msg)
                        continue

                    # If all dependencies met, trigger silver notebook
                    if should_trigger_silver("tpcds", run_date) and silver_nb_id:
                        silver_run = trigger_notebook(silver_nb_id, "all")
                        if silver_run:
                            silver_outcome = poll_job_status(silver_nb_id, silver_run, "notebook")
                            log.info("  Silver notebook: %s", silver_outcome)

                    audit.update({"table": table, "outcome": outcome, "status": "done"})

                    if outcome in ("succeeded", "coordinated"):
                        receiver.complete_message(msg)
                        log.info("  ✓ Message completed: %s → %s", table, outcome)
                    else:
                        receiver.abandon_message(msg)
                        log.warning("  ✗ Message abandoned: %s → %s", table, outcome)

                except Exception as e:
                    log.error("  Fatal error processing message: %s", e)
                    receiver.abandon_message(msg)
                    audit.update({"status": "error", "error": str(e)})

                log.info("  Audit: %s", json.dumps(audit))


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Event-driven Fabric job trigger")
    parser.add_argument("--setup",       action="store_true", help="Create Event Grid + Service Bus")
    parser.add_argument("--consume",     action="store_true", help="Start consumer loop")
    parser.add_argument("--test-event",  metavar="TABLE",     help="Simulate a blob event for TABLE")
    parser.add_argument("--show-state",  action="store_true", help="Show silver coordination state")
    parser.add_argument("--max-messages",type=int, default=0, help="Stop after N messages (0=forever)")
    args = parser.parse_args()

    if args.setup:
        log.info("Setting up event pipeline infrastructure...")
        setup_servicebus()
        setup_event_grid()
        log.info("✓ Event pipeline infrastructure ready")
        return

    if args.show_state:
        print(json.dumps({k: {"arrived": list(v["arrived"]), "triggered": v["triggered"]}
                          for k, v in _silver_state.items()}, indent=2))
        return

    if args.test_event:
        # Simulate a blob event to test routing logic without real Event Grid
        table = args.test_event
        fake_event = {
            "id":        f"test-{int(time.time())}",
            "eventType": "Microsoft.Storage.BlobCreated",
            "subject":   f"/blobServices/default/containers/raw-zone/blobs/{RAW_BLOB_PREFIX}{table}/test.parquet",
            "eventTime": datetime.now(timezone.utc).isoformat(),
            "data": {
                "url":           f"https://example.blob.core.windows.net/raw-zone/{RAW_BLOB_PREFIX}{table}/test.parquet",
                "contentLength": 102400,
            }
        }
        event = parse_blob_event(fake_event)
        log.info("Parsed test event: %s", json.dumps(event, indent=2))
        route = "CopyJob" if table in COPYJOB_TABLES else "Notebook (Silver)" if table in NOTEBOOK_TABLES else "Unknown"
        log.info("Route: %s → %s", table, route)
        return

    if args.consume:
        consume(max_messages=args.max_messages)
        return

    parser.print_help()


if __name__ == "__main__":
    main()
