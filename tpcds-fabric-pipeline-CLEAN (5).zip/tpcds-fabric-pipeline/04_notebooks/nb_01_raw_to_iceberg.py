# %% [markdown]
# # Raw → Iceberg (Prepared Zone)
# Reads parquet files from ADLS raw-zone and writes Iceberg tables
# to the ADLS prepared-zone using a Hadoop file-based catalog.
#
# Called by the Fabric Data Pipeline AFTER Copy Job activities complete.
#
# Hadoop catalog layout in prepared-zone:
#   tpcds-prepared/tpcds/iceberg/{table}/
#       ├── metadata/   ← Iceberg snapshots, manifests, schema evolution
#       └── data/       ← Parquet data files (snappy compressed)
#
# No external metastore required — catalog is entirely file-based in ADLS.

# %% ── Parameters (injected by pipeline or set manually) ────────────────────
import json
from notebookutils import mssparkutils

# These are overridden when called from the ADF pipeline via notebook parameters
ADLS_ACCOUNT        = mssparkutils.notebook.getParam("adls_account",        "YOUR_ADLS_ACCOUNT_NAME")
RAW_CONTAINER       = mssparkutils.notebook.getParam("raw_container",        "tpcds-raw")
RAW_BASE_PATH       = mssparkutils.notebook.getParam("raw_base_path",        "tpcds/tables")
PREPARED_CONTAINER  = mssparkutils.notebook.getParam("prepared_container",   "tpcds-prepared")
PREPARED_BASE_PATH  = mssparkutils.notebook.getParam("prepared_base_path",   "tpcds/iceberg")
TABLES_PARAM        = mssparkutils.notebook.getParam("tables",               "")

TABLES = json.loads(TABLES_PARAM) if TABLES_PARAM else [
    "date_dim", "time_dim", "customer", "customer_address",
    "customer_demographics", "household_demographics", "income_band",
    "item", "store", "call_center", "catalog_page",
    "web_site", "web_page", "warehouse", "ship_mode", "reason", "promotion",
    "store_sales", "store_returns", "catalog_sales", "catalog_returns",
    "web_sales", "web_returns", "inventory",
]

# ABFSS paths
RAW_ROOT      = f"abfss://{RAW_CONTAINER}@{ADLS_ACCOUNT}.dfs.core.windows.net/{RAW_BASE_PATH}"
PREPARED_ROOT = f"abfss://{PREPARED_CONTAINER}@{ADLS_ACCOUNT}.dfs.core.windows.net/{PREPARED_BASE_PATH}"

print(f"Raw zone      : {RAW_ROOT}")
print(f"Prepared zone : {PREPARED_ROOT}")
print(f"Tables        : {len(TABLES)}")

# %% ── Spark session — Hadoop catalog pointed at ADLS prepared-zone ──────────
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp, lit
from datetime import datetime

spark = SparkSession.builder \
    .appName("tpcds_raw_to_iceberg") \
    .config("spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
    .config("spark.sql.catalog.prepared",
            "org.apache.iceberg.spark.SparkCatalog") \
    .config("spark.sql.catalog.prepared.type",         "hadoop") \
    .config("spark.sql.catalog.prepared.warehouse",    PREPARED_ROOT) \
    .config("spark.sql.defaultCatalog",                "prepared") \
    .config("spark.sql.parquet.int96RebaseMode",       "CORRECTED") \
    .config("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED") \
    .getOrCreate()

# Mount ADLS with SPN credentials (Fabric uses linked service auth automatically
# when the notebook runs inside a pipeline — no explicit credentials needed)
print(f"Spark version : {spark.version}")
print(f"Started at    : {datetime.now().isoformat()}")

# %% ── Helper: write one Iceberg table to prepared-zone ──────────────────────
def write_iceberg(table_name: str) -> dict:
    """
    Read parquet from raw-zone ADLS and write as Iceberg to prepared-zone ADLS.
    Uses Hadoop catalog — metadata and data files all land in ADLS.

    prepared-zone layout:
      {PREPARED_ROOT}/{table_name}/
          metadata/  ← version-hint.text, v*.metadata.json, *.avro manifests
          data/      ← *.parquet files (snappy)
    """
    src_path = f"{RAW_ROOT}/{table_name}/"
    tgt_name = f"prepared.{table_name}"

    print(f"\n  [{table_name}]")
    print(f"    Source : {src_path}")
    print(f"    Target : {tgt_name}  →  {PREPARED_ROOT}/{table_name}/")

    try:
        df = spark.read \
            .option("mergeSchema", "true") \
            .parquet(src_path)
    except Exception as e:
        print(f"    ✗ Read FAILED: {e}")
        return {"table": table_name, "status": "error", "error": str(e)}

    row_count = df.count()
    print(f"    Rows   : {row_count:,}")

    # Add audit columns
    df = df \
        .withColumn("_ingested_at",   current_timestamp()) \
        .withColumn("_source_layer",  lit("prepared")) \
        .withColumn("_source_path",   lit(src_path))

    # Write Iceberg — createOrReplace handles re-runs cleanly
    try:
        df.writeTo(tgt_name) \
          .tableProperty("write.format.default",          "parquet") \
          .tableProperty("write.parquet.compression-codec","snappy") \
          .tableProperty("write.metadata.compression-codec","gzip") \
          .tableProperty("write.target-file-size-bytes",  str(128 * 1024 * 1024)) \
          .tableProperty("history.expire.min-snapshots-to-keep", "3") \
          .using("iceberg") \
          .createOrReplace()

        # Verify by reading back the metadata
        snap = spark.sql(f"SELECT snapshot_id, committed_at, operation "
                         f"FROM prepared.{table_name}.snapshots "
                         f"ORDER BY committed_at DESC LIMIT 1")
        snap_row = snap.collect()[0] if snap.count() > 0 else None
        snap_id  = snap_row["snapshot_id"] if snap_row else "unknown"

        print(f"    ✓ Iceberg written  rows={row_count:,}  snapshot={snap_id}")
        return {"table": table_name, "status": "ok", "rows": row_count, "snapshot_id": snap_id}

    except Exception as e:
        print(f"    ✗ Write FAILED: {e}")
        return {"table": table_name, "status": "error", "error": str(e)}


# %% ── Process all tables ─────────────────────────────────────────────────────
print("\n" + "=" * 65)
print("  Writing Iceberg tables to ADLS prepared-zone")
print("  Catalog: Hadoop (file-based)")
print("=" * 65)

# Dimensions first (lighter), then facts
dim_tables  = [t for t in TABLES if t not in
               ("store_sales", "store_returns", "catalog_sales",
                "catalog_returns", "web_sales", "web_returns", "inventory")]
fact_tables = [t for t in TABLES if t not in dim_tables]

results = []

print(f"\n[1/2] Dimension tables ({len(dim_tables)})")
for tbl in dim_tables:
    results.append(write_iceberg(tbl))

print(f"\n[2/2] Fact tables ({len(fact_tables)})")
for tbl in fact_tables:
    results.append(write_iceberg(tbl))

# %% ── Validate: show Iceberg table metadata ─────────────────────────────────
print("\n── Iceberg table validation ──────────────────────────────────")
spark.sql("""
    SHOW TABLES IN prepared
""").show(30, truncate=False)

print("\nSnapshot summary (last snapshot per table):")
for r in results:
    if r["status"] == "ok":
        try:
            spark.sql(f"""
                SELECT '{r["table"]}' AS table_name,
                       snapshot_id, operation,
                       DATE(committed_at) AS committed_date,
                       summary['total-records'] AS total_records
                FROM   prepared.{r["table"]}.snapshots
                ORDER  BY committed_at DESC
                LIMIT  1
            """).show(truncate=False)
        except Exception:
            pass

# %% ── Summary ────────────────────────────────────────────────────────────────
ok     = [r for r in results if r["status"] == "ok"]
errors = [r for r in results if r["status"] == "error"]
total  = sum(r.get("rows", 0) for r in ok)

print("\n" + "=" * 65)
print(f"  Raw → Iceberg complete")
print(f"  Tables written  : {len(ok)} / {len(TABLES)}")
print(f"  Tables failed   : {len(errors)}")
print(f"  Total rows      : {total:,}")
print(f"  Prepared zone   : {PREPARED_ROOT}")
print(f"  Completed at    : {datetime.now().isoformat()}")

if errors:
    print("\n  ❌ Failed tables:")
    for r in errors:
        print(f"     {r['table']:35s} → {r['error']}")
    raise RuntimeError(
        f"{len(errors)} tables failed writing Iceberg. "
        "Fix errors before shortcut refresh step."
    )

print("\n  ✅ All Iceberg tables ready in ADLS prepared-zone.")
print("     Shortcut refresh / creation step will run next.")
