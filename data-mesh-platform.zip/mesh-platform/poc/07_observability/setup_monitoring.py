"""
poc/07_observability/setup_monitoring.py
=========================================
JIRA: OBS-1 — Centralised logging → Log Analytics (all pipeline stages)
JIRA: OBS-2 — Purview lineage scan automation
JIRA: OBS-3 — Data Product SLO dashboard

Data Mesh Plane: Infrastructure Plane (shared service, platform-owned)
Owner: Platform Engineering Team

Demonstrates:
  - Log Analytics workspace + DCE + DCR creation (structured pipeline logs)
  - Python DataMeshLogger class — drop-in for all pipeline stages
  - KQL queries for pipeline health, DQ, SLO, cost-by-domain
  - Purview data source registration + scan trigger
  - SLO measurement: freshness, quality, availability per data product
  - Azure Monitor workbook JSON (importable via portal)

Run:
    python poc/07_observability/setup_monitoring.py --setup
    python poc/07_observability/setup_monitoring.py --test-log
    python poc/07_observability/setup_monitoring.py --purview-scan
    python poc/07_observability/setup_monitoring.py --slo-check
    python poc/07_observability/setup_monitoring.py --print-kql
"""

import os
import sys
import json
import time
import logging
import argparse
import hashlib
import requests
from pathlib import Path
from datetime import datetime, timezone, timedelta

import yaml
from azure.identity import AzureCliCredential
from azure.monitor.ingestion import LogsIngestionClient

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(message)s")

ROOT = Path(__file__).resolve().parents[2]
CFG  = yaml.safe_load((ROOT / "config.yaml").read_text()) if (ROOT / "config.yaml").exists() else {}

TENANT_ID       = CFG.get("azure", {}).get("tenant_id",       "YOUR_TENANT_ID")
SUBSCRIPTION_ID = CFG.get("azure", {}).get("subscription_id", "YOUR_SUBSCRIPTION_ID")
RESOURCE_GROUP  = CFG.get("azure", {}).get("resource_group",  "rg-fabric-platform")
LOCATION        = CFG.get("azure", {}).get("location",        "uksouth")
PURVIEW_ACCOUNT = CFG.get("governance", {}).get("purview_account", "YOUR_PURVIEW_ACCOUNT")
ADLS_ACCOUNT    = CFG.get("adls", {}).get("account_name",     "YOUR_ADLS_ACCOUNT")

WORKSPACE_NAME  = "law-fabric-platform"
DCE_NAME        = "dce-fabric-platform"
ARM_BASE        = "https://management.azure.com"


def arm_headers() -> dict:
    t = AzureCliCredential().get_token("https://management.azure.com/.default")
    return {"Authorization": f"Bearer {t.token}", "Content-Type": "application/json"}


# ══════════════════════════════════════════════════════════════════════════════
# 1. INFRASTRUCTURE SETUP — Log Analytics + DCE + DCR
# ══════════════════════════════════════════════════════════════════════════════

def setup_log_analytics() -> dict:
    """Create Log Analytics workspace with 90-day retention."""
    log.info("Creating Log Analytics workspace: %s", WORKSPACE_NAME)
    url = (
        f"{ARM_BASE}/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.OperationalInsights/workspaces/{WORKSPACE_NAME}"
        f"?api-version=2022-10-01"
    )
    resp = requests.put(url, json={
        "location": LOCATION,
        "properties": {
            "sku":              {"name": "PerGB2018"},
            "retentionInDays":  90,
            "features": {
                "enableLogAccessUsingOnlyResourcePermissions": True
            },
        },
        "tags": {"data-mesh-plane": "infrastructure", "component": "observability"},
    }, headers=arm_headers(), timeout=60)

    if resp.status_code not in (200, 201, 202):
        log.error("LAW creation failed: %d — %s", resp.status_code, resp.text[:200])
        return {}

    log.info("  ✓ Log Analytics workspace: %s  (%d)", WORKSPACE_NAME, resp.status_code)
    return resp.json()


def setup_dce() -> dict:
    """Create Data Collection Endpoint for custom log ingestion."""
    log.info("Creating Data Collection Endpoint: %s", DCE_NAME)
    url = (
        f"{ARM_BASE}/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.Insights/dataCollectionEndpoints/{DCE_NAME}"
        f"?api-version=2022-06-01"
    )
    resp = requests.put(url, json={
        "location": LOCATION,
        "properties": {"networkAcls": {"publicNetworkAccess": "Enabled"}},
        "tags": {"data-mesh-plane": "infrastructure"},
    }, headers=arm_headers(), timeout=30)
    log.info("  ✓ DCE: %s  (%d)", DCE_NAME, resp.status_code)
    return resp.json() if resp.status_code in (200, 201) else {}


def setup_dcr(workspace_resource_id: str, dce_resource_id: str) -> dict:
    """
    Create Data Collection Rule defining custom log tables:
      - DataPipelineRun    : per-stage pipeline run events
      - DataQualityMetric  : DQ rule results per table
      - IngestionEvent     : on-prem → ADLS upload events
      - JobTrigger         : Service Bus → Fabric job trigger events
      - SloMeasurement     : hourly SLO measurements per data product
    """
    log.info("Creating Data Collection Rule...")
    dcr_name = "dcr-fabric-pipeline"
    url = (
        f"{ARM_BASE}/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{RESOURCE_GROUP}"
        f"/providers/Microsoft.Insights/dataCollectionRules/{dcr_name}"
        f"?api-version=2022-06-01"
    )

    tables_schema = {
        "DataPipelineRun_CL": [
            {"name": "run_id",       "type": "string"},
            {"name": "stage",        "type": "string"},
            {"name": "table_name",   "type": "string"},
            {"name": "domain",       "type": "string"},
            {"name": "status",       "type": "string"},
            {"name": "duration_ms",  "type": "long"},
            {"name": "rows_in",      "type": "long"},
            {"name": "rows_out",     "type": "long"},
            {"name": "error",        "type": "string"},
        ],
        "DataQualityMetric_CL": [
            {"name": "run_id",       "type": "string"},
            {"name": "table_name",   "type": "string"},
            {"name": "rule_name",    "type": "string"},
            {"name": "column_name",  "type": "string"},
            {"name": "pass_count",   "type": "long"},
            {"name": "fail_count",   "type": "long"},
            {"name": "fail_rate",    "type": "real"},
        ],
        "IngestionEvent_CL": [
            {"name": "run_id",          "type": "string"},
            {"name": "source_system",   "type": "string"},
            {"name": "table_name",      "type": "string"},
            {"name": "extract_mode",    "type": "string"},
            {"name": "row_count",       "type": "long"},
            {"name": "size_bytes",      "type": "long"},
            {"name": "checksum",        "type": "string"},
            {"name": "status",          "type": "string"},
        ],
        "JobTrigger_CL": [
            {"name": "event_id",    "type": "string"},
            {"name": "table_name",  "type": "string"},
            {"name": "job_type",    "type": "string"},
            {"name": "fabric_job_id","type":"string"},
            {"name": "outcome",     "type": "string"},
            {"name": "latency_ms",  "type": "long"},
        ],
        "SloMeasurement_CL": [
            {"name": "data_product",     "type": "string"},
            {"name": "slo_freshness_hrs","type": "real"},
            {"name": "actual_age_hrs",   "type": "real"},
            {"name": "dq_pass_rate",     "type": "real"},
            {"name": "availability_pct", "type": "real"},
            {"name": "freshness_ok",     "type": "boolean"},
            {"name": "quality_ok",       "type": "boolean"},
            {"name": "availability_ok",  "type": "boolean"},
            {"name": "overall_ok",       "type": "boolean"},
        ],
    }

    streams    = []
    outputs    = {}
    transforms = {}

    for table, cols in tables_schema.items():
        stream_name = f"Custom-{table}"
        streams.append({
            "name":    stream_name,
            "columns": cols + [{"name": "TimeGenerated", "type": "datetime"}],
        })
        outputs[table]    = {"workspace": {"resourceId": workspace_resource_id, "tableNamePrefix": ""}}
        transforms[table] = "source"

    resp = requests.put(url, json={
        "location": LOCATION,
        "properties": {
            "dataCollectionEndpointId": dce_resource_id,
            "streamDeclarations": {s["name"]: {"columns": s["columns"]} for s in streams},
            "destinations": {"logAnalytics": [{"workspaceResourceId": workspace_resource_id, "name": "law"}]},
            "dataFlows": [
                {
                    "streams":      [s["name"]],
                    "destinations": ["law"],
                    "transformKql": "source",
                    "outputStream": f"Custom-{list(tables_schema.keys())[i]}",
                }
                for i, s in enumerate(streams)
            ],
        },
        "tags": {"data-mesh-plane": "infrastructure"},
    }, headers=arm_headers(), timeout=30)

    log.info("  ✓ DCR: %s  (%d)", dcr_name, resp.status_code)
    return resp.json() if resp.status_code in (200, 201) else {}


# ══════════════════════════════════════════════════════════════════════════════
# 2. DataMeshLogger — drop-in class for all pipeline stages
# ══════════════════════════════════════════════════════════════════════════════

class DataMeshLogger:
    """
    Structured logger that emits events to Log Analytics via DCE.
    Drop-in for all pipeline stages — no SDK/driver required.

    Usage:
        logger = DataMeshLogger(dce_endpoint, dcr_immutable_id, domain="retail")
        with logger.stage("silver_transform", table="store_sales") as ctx:
            # ... do work ...
            ctx["rows_in"] = 50000
            ctx["rows_out"] = 49800

    Emits DataPipelineRun_CL event on context exit.
    """

    def __init__(self, dce_endpoint: str, dcr_immutable_id: str, domain: str = "platform"):
        self.endpoint   = dce_endpoint
        self.dcr_id     = dcr_immutable_id
        self.domain     = domain
        self.run_id     = f"run-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        self._cred      = AzureCliCredential()
        log.info("DataMeshLogger initialised — run_id=%s domain=%s", self.run_id, domain)

    def _ingest(self, stream: str, records: list):
        """Send records to Log Analytics via DCE."""
        try:
            client = LogsIngestionClient(
                endpoint=self.endpoint,
                credential=self._cred,
            )
            client.upload(
                rule_id=self.dcr_id,
                stream_name=f"Custom-{stream}",
                logs=records,
            )
        except Exception as e:
            # Never let logging failure break the pipeline
            log.warning("Log ingestion failed (non-fatal): %s", e)

    def pipeline_run(self, stage: str, table: str = "",
                     status: str = "succeeded", duration_ms: int = 0,
                     rows_in: int = 0, rows_out: int = 0, error: str = ""):
        self._ingest("DataPipelineRun_CL", [{
            "TimeGenerated": datetime.now(timezone.utc).isoformat(),
            "run_id":       self.run_id,
            "stage":        stage,
            "table_name":   table,
            "domain":       self.domain,
            "status":       status,
            "duration_ms":  duration_ms,
            "rows_in":      rows_in,
            "rows_out":     rows_out,
            "error":        error,
        }])

    def dq_metric(self, table: str, rule: str, column: str,
                  pass_count: int, fail_count: int):
        total = pass_count + fail_count
        self._ingest("DataQualityMetric_CL", [{
            "TimeGenerated": datetime.now(timezone.utc).isoformat(),
            "run_id":      self.run_id,
            "table_name":  table,
            "rule_name":   rule,
            "column_name": column,
            "pass_count":  pass_count,
            "fail_count":  fail_count,
            "fail_rate":   fail_count / total if total else 0.0,
        }])

    def ingestion_event(self, source: str, table: str, mode: str,
                        rows: int, size: int, checksum: str, status: str):
        self._ingest("IngestionEvent_CL", [{
            "TimeGenerated":  datetime.now(timezone.utc).isoformat(),
            "run_id":         self.run_id,
            "source_system":  source,
            "table_name":     table,
            "extract_mode":   mode,
            "row_count":      rows,
            "size_bytes":     size,
            "checksum":       checksum,
            "status":         status,
        }])

    def job_trigger(self, event_id: str, table: str, job_type: str,
                    fabric_job_id: str, outcome: str, latency_ms: int):
        self._ingest("JobTrigger_CL", [{
            "TimeGenerated":  datetime.now(timezone.utc).isoformat(),
            "event_id":       event_id,
            "table_name":     table,
            "job_type":       job_type,
            "fabric_job_id":  fabric_job_id,
            "outcome":        outcome,
            "latency_ms":     latency_ms,
        }])

    def slo_measurement(self, product: str, slo_freshness_hrs: float,
                        actual_age_hrs: float, dq_pass_rate: float, availability_pct: float):
        freshness_ok    = actual_age_hrs   <= slo_freshness_hrs
        quality_ok      = dq_pass_rate     >= 0.95
        availability_ok = availability_pct >= 0.99
        self._ingest("SloMeasurement_CL", [{
            "TimeGenerated":      datetime.now(timezone.utc).isoformat(),
            "data_product":       product,
            "slo_freshness_hrs":  slo_freshness_hrs,
            "actual_age_hrs":     actual_age_hrs,
            "dq_pass_rate":       dq_pass_rate,
            "availability_pct":   availability_pct,
            "freshness_ok":       freshness_ok,
            "quality_ok":         quality_ok,
            "availability_ok":    availability_ok,
            "overall_ok":         all([freshness_ok, quality_ok, availability_ok]),
        }])
        status = "✓" if all([freshness_ok, quality_ok, availability_ok]) else "✗"
        log.info("  SLO %s %-30s  age=%.1fh  dq=%.2f%%  avail=%.2f%%",
                 status, product, actual_age_hrs, dq_pass_rate*100, availability_pct*100)


# ══════════════════════════════════════════════════════════════════════════════
# 3. KQL QUERIES — pipeline health, DQ, SLO, cost
# ══════════════════════════════════════════════════════════════════════════════

KQL_QUERIES = {
    "pipeline_health_24h": """
// Pipeline health — last 24 hours by stage and status
DataPipelineRun_CL
| where TimeGenerated > ago(24h)
| summarize
    runs       = count(),
    succeeded  = countif(status == "succeeded"),
    failed     = countif(status == "failed"),
    avg_dur_s  = round(avg(duration_ms) / 1000, 1),
    total_rows = sum(rows_out)
  by stage, domain
| extend success_rate = round(todouble(succeeded) / runs * 100, 1)
| order by success_rate asc
""",

    "dq_trend_7d": """
// DQ fail rate trend — last 7 days by table
DataQualityMetric_CL
| where TimeGenerated > ago(7d)
| summarize
    total_checks = sum(pass_count + fail_count),
    total_fails  = sum(fail_count),
    fail_rate    = round(sum(fail_count) * 100.0 / sum(pass_count + fail_count), 2)
  by table_name, rule_name, bin(TimeGenerated, 1d)
| where fail_rate > 1
| order by fail_rate desc
""",

    "ingestion_volume_by_day": """
// Ingestion volume — rows and bytes per day
IngestionEvent_CL
| where TimeGenerated > ago(30d)
| summarize
    tables_loaded = dcount(table_name),
    total_rows    = sum(row_count),
    total_mb      = round(sum(size_bytes) / 1e6, 1),
    full_loads    = countif(extract_mode == "full"),
    incr_loads    = countif(extract_mode == "incremental"),
    failures      = countif(status != "success")
  by bin(TimeGenerated, 1d)
| order by TimeGenerated desc
""",

    "event_trigger_latency": """
// Event-driven pipeline latency: blob created → Fabric job started
JobTrigger_CL
| where TimeGenerated > ago(24h)
| summarize
    triggers     = count(),
    succeeded    = countif(outcome == "succeeded"),
    avg_lat_ms   = round(avg(latency_ms), 0),
    p95_lat_ms   = round(percentile(latency_ms, 95), 0),
    max_lat_ms   = max(latency_ms)
  by job_type, table_name
| extend p95_lat_s = round(todouble(p95_lat_ms) / 1000, 1)
| order by avg_lat_ms desc
""",

    "slo_dashboard": """
// SLO status — latest measurement per data product
SloMeasurement_CL
| summarize arg_max(TimeGenerated, *) by data_product
| project
    data_product,
    freshness = iff(freshness_ok, "✓", "✗"),
    quality   = iff(quality_ok,   "✓", "✗"),
    avail     = iff(availability_ok, "✓", "✗"),
    overall   = iff(overall_ok, "PASS", "BREACH"),
    age_hrs   = round(actual_age_hrs, 1),
    dq_rate   = strcat(round(dq_pass_rate * 100, 1), "%"),
    avail_pct = strcat(round(availability_pct, 2), "%")
| order by overall asc
""",

    "capacity_cost_by_domain": """
// Fabric CU consumption by domain (requires Fabric capacity metrics)
// Approximate cost: F2 = £0.36/hr, each CU adds proportionally
FabricCapacityMetrics
| where TimeGenerated > ago(30d)
| summarize
    avg_cu_pct   = round(avg(MetricValue), 1),
    peak_cu_pct  = max(MetricValue),
    hours_above_70 = countif(MetricValue > 70) / 12.0  // 5-min buckets
  by bin(TimeGenerated, 1d)
| extend estimated_cost_gbp = round(hours_above_70 * 0.36, 2)
| order by TimeGenerated desc
""",

    "silver_dependency_state": """
// Silver coordination: which raw tables have arrived for each run_date
// (logged when event consumer marks table as arrived)
JobTrigger_CL
| where TimeGenerated > ago(48h)
| where job_type == "coordination"
| summarize tables_arrived = make_set(table_name) by bin(TimeGenerated, 1d)
| extend arrival_count = array_length(tables_arrived)
| order by TimeGenerated desc
""",
}


def print_kql_queries():
    print("\n" + "="*70)
    print("  KQL QUERIES — paste into Log Analytics / Azure Monitor")
    print("="*70)
    for name, kql in KQL_QUERIES.items():
        print(f"\n── {name} ──")
        print(kql.strip())
    print("\n" + "="*70)


# ══════════════════════════════════════════════════════════════════════════════
# 4. PURVIEW — data source registration + scan trigger
# ══════════════════════════════════════════════════════════════════════════════

def purview_headers() -> dict:
    t = AzureCliCredential().get_token("https://purview.azure.net/.default")
    return {"Authorization": f"Bearer {t.token}", "Content-Type": "application/json"}


def register_purview_data_source():
    """Register ADLS prepared-zone as a Purview data source."""
    log.info("Registering ADLS data source in Purview: %s", PURVIEW_ACCOUNT)
    base = f"https://{PURVIEW_ACCOUNT}.purview.azure.com"

    payload = {
        "name":       f"adls-{ADLS_ACCOUNT}-prepared",
        "kind":       "AdlsGen2",
        "properties": {
            "endpoint":             f"https://{ADLS_ACCOUNT}.dfs.core.windows.net",
            "resourceGroup":        RESOURCE_GROUP,
            "subscriptionId":       SUBSCRIPTION_ID,
            "location":             LOCATION,
            "collection": {"type": "CollectionReference", "referenceName": "tpcds-fabric"},
        }
    }
    resp = requests.put(
        f"{base}/scan/datasources/adls-{ADLS_ACCOUNT}-prepared",
        json=payload, headers=purview_headers(), timeout=30
    )
    log.info("  Data source registration: %d", resp.status_code)
    return resp.status_code in (200, 201)


def create_purview_scan(layer: str, path_prefix: str) -> str:
    """Create a scan definition for a specific Iceberg layer."""
    log.info("Creating Purview scan for layer: %s  prefix: %s", layer, path_prefix)
    base = f"https://{PURVIEW_ACCOUNT}.purview.azure.com"
    scan_name = f"scan-tpcds-{layer}"

    payload = {
        "name": scan_name,
        "kind": "AdlsGen2Msi",
        "properties": {
            "scanRulesetName":    "AdlsGen2",
            "scanRulesetType":    "System",
            "collection": {"type": "CollectionReference", "referenceName": "tpcds-fabric"},
            "filter": {
                "excludeUriPrefixes": [],
                "includeUriPrefixes": [
                    f"https://{ADLS_ACCOUNT}.dfs.core.windows.net/prepared-zone/{path_prefix}"
                ]
            }
        }
    }
    resp = requests.put(
        f"{base}/scan/datasources/adls-{ADLS_ACCOUNT}-prepared/scans/{scan_name}",
        json=payload, headers=purview_headers(), timeout=30
    )
    log.info("  Scan created: %s  (%d)", scan_name, resp.status_code)
    return scan_name


def trigger_purview_scan(scan_name: str) -> str:
    """Trigger a Purview scan and return the run_id."""
    base    = f"https://{PURVIEW_ACCOUNT}.purview.azure.com"
    run_id  = f"scan-run-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
    resp    = requests.put(
        f"{base}/scan/datasources/adls-{ADLS_ACCOUNT}-prepared/scans/{scan_name}/runs/{run_id}",
        json={}, headers=purview_headers(), timeout=30
    )
    log.info("  Scan triggered: %s  run=%s  (%d)", scan_name, run_id, resp.status_code)
    return run_id


def run_purview_scan_pipeline():
    """Register + create + trigger scans for all three Iceberg layers."""
    register_purview_data_source()
    layers = {
        "raw":    "tpcds/iceberg",
        "silver": "tpcds/silver",
        "gold":   "tpcds/gold",
    }
    for layer, prefix in layers.items():
        scan_name = create_purview_scan(layer, prefix)
        time.sleep(2)
        trigger_purview_scan(scan_name)

    log.info("✓ Purview scans triggered for all 3 layers")
    log.info("  Check progress: https://%s.purview.azure.com → Data Catalog → Scans", PURVIEW_ACCOUNT)


# ══════════════════════════════════════════════════════════════════════════════
# 5. SLO CHECK — freshness, quality, availability
# ══════════════════════════════════════════════════════════════════════════════

# SLO configuration per data product
SLO_CONFIG = {
    "gold_sales_fact":        {"freshness_hrs": 4,  "dq_min": 0.98, "avail_min": 0.99},
    "gold_customer_360":      {"freshness_hrs": 8,  "dq_min": 0.97, "avail_min": 0.99},
    "gold_product_performance":{"freshness_hrs": 8,  "dq_min": 0.97, "avail_min": 0.99},
}


def measure_slos(dce_endpoint: str, dcr_immutable_id: str):
    """
    Measure SLOs for each gold data product.
    In production: reads Iceberg snapshot timestamps from ADLS metadata.
    Here: simulated with synthetic values for POC demonstration.
    """
    logger = DataMeshLogger(dce_endpoint, dcr_immutable_id, domain="platform")

    log.info("\n── SLO Measurements ──")
    all_pass = True

    for product, slo in SLO_CONFIG.items():
        # In production: read Iceberg metadata.json for actual snapshot timestamp
        # here we simulate with synthetic values
        import random
        rng = random.Random(hash(product) % 1000)
        actual_age   = rng.uniform(0.5, slo["freshness_hrs"] * 1.2)
        dq_pass_rate = rng.uniform(0.94, 0.999)
        avail_pct    = rng.uniform(0.975, 1.0) * 100

        logger.slo_measurement(
            product      = product,
            slo_freshness_hrs = slo["freshness_hrs"],
            actual_age_hrs    = actual_age,
            dq_pass_rate      = dq_pass_rate,
            availability_pct  = avail_pct,
        )

        ok = (actual_age <= slo["freshness_hrs"] and
              dq_pass_rate >= slo["dq_min"] and
              avail_pct / 100 >= slo["avail_min"])
        if not ok:
            all_pass = False

    log.info("\n  Overall SLO: %s", "✓ ALL PASS" if all_pass else "✗ BREACH DETECTED")
    return all_pass


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Platform observability setup")
    parser.add_argument("--setup",        action="store_true", help="Create Log Analytics + DCE + DCR")
    parser.add_argument("--test-log",     action="store_true", help="Emit test log events")
    parser.add_argument("--purview-scan", action="store_true", help="Register + trigger Purview scans")
    parser.add_argument("--slo-check",    action="store_true", help="Measure SLOs for all gold products")
    parser.add_argument("--print-kql",    action="store_true", help="Print KQL dashboard queries")
    args = parser.parse_args()

    if args.print_kql:
        print_kql_queries()
        return

    if args.setup:
        law  = setup_log_analytics()
        dce  = setup_dce()
        law_id = law.get("id", "")
        dce_id = dce.get("id", "")
        if law_id and dce_id:
            setup_dcr(law_id, dce_id)
            log.info("\n✓ Observability infrastructure ready")
            log.info("  Log Analytics : %s", WORKSPACE_NAME)
            log.info("  DCE           : %s", DCE_NAME)
            log.info("  Custom tables : DataPipelineRun_CL, DataQualityMetric_CL, IngestionEvent_CL, JobTrigger_CL, SloMeasurement_CL")
        return

    # For --test-log and --slo-check, need DCE endpoint + DCR immutable ID
    dce_endpoint    = os.getenv("DCE_ENDPOINT",    "https://YOUR-DCE.uksouth-1.ingest.monitor.azure.com")
    dcr_immutable_id = os.getenv("DCR_IMMUTABLE_ID", "dcr-xxxxxxxx")

    if args.test_log:
        logger = DataMeshLogger(dce_endpoint, dcr_immutable_id, domain="retail-tpcds")
        log.info("Emitting test log events...")
        logger.pipeline_run("ingestion",         "store_sales",  "succeeded", 12400, 50000, 49800)
        logger.pipeline_run("silver_transform",  "store_sales",  "succeeded", 34200, 49800, 49500)
        logger.pipeline_run("gold_curated",      "sales_fact",   "succeeded", 56100, 149000, 149000)
        logger.dq_metric("store_sales", "not_null",   "ss_item_sk",     49800, 0)
        logger.dq_metric("store_sales", "range_check","ss_sales_price",  49500, 300)
        logger.ingestion_event("onprem-sql", "store_sales", "incremental", 50000, 5_242_880, "abc123", "success")
        logger.job_trigger("evt-001", "store_sales", "copyjob", "fab-job-001", "succeeded", 28400)
        log.info("✓ Test log events emitted — check Log Analytics in ~5 min")

    if args.slo_check:
        measure_slos(dce_endpoint, dcr_immutable_id)

    if args.purview_scan:
        run_purview_scan_pipeline()

    if not any([args.setup, args.test_log, args.purview_scan, args.slo_check, args.print_kql]):
        parser.print_help()


if __name__ == "__main__":
    main()
