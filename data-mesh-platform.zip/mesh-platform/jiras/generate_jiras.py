"""
jiras/generate_jiras.py
========================
Generates the full Data Mesh Platform backlog as:
  - jira_export.json   (importable via JIRA CSV/JSON importer)
  - jira_board.html    (visual sprint board for stakeholder review)

Data Mesh Multi-Plane Model:
  Plane 1 — Data Infrastructure   : capacities, workspaces, networking, identity
  Plane 2 — Data Platform          : ingestion, pipelines, storage, compute
  Plane 3 — Data Product           : ETL, warehouse, semantic model, contracts
  Plane 4 — Mesh Experience        : governance, catalogue, observability, DLP

Run:
    python jiras/generate_jiras.py
    # opens jira_board.html in browser
"""

import json
import webbrowser
from pathlib import Path
from datetime import date

TODAY = date.today().isoformat()
OUT   = Path(__file__).parent


# ══════════════════════════════════════════════════════════════════════════════
# BACKLOG DEFINITION
# Each epic → list of stories → list of tasks (sub-tasks)
# Fields: key, summary, description, acceptance_criteria, points, labels,
#         component, priority, poc_file
# ══════════════════════════════════════════════════════════════════════════════

BACKLOG = [

  # ── EPIC 1: DATA INFRASTRUCTURE PLANE ─────────────────────────────────────
  {
    "key": "INFRA", "type": "Epic", "priority": "High",
    "component": "Infrastructure Plane",
    "color": "#0ea5e9",
    "summary": "Data Infrastructure Plane — Fabric Capacity, Workspaces, Networking, Identity",
    "description": (
      "Establish the shared infrastructure plane that all data product teams consume. "
      "Covers Fabric capacity lifecycle, workspace-per-domain provisioning, private networking, "
      "federated identity model (Immuta + Entra), and IaC automation. "
      "This plane is owned by the Data Platform Engineering team, NOT individual domain teams."
    ),
    "stories": [
      {
        "key": "INFRA-1", "summary": "POC: Fabric Capacity provisioning and auto-scale via REST API",
        "points": 8, "priority": "High", "poc_file": "poc/01_infrastructure/provision_capacity.py",
        "description": (
          "Provision an F64 Fabric capacity programmatically using Azure Resource Manager REST API. "
          "Implement capacity scaling (pause/resume) and throttle detection. "
          "Establish naming convention and tagging strategy for multi-team platform."
        ),
        "acceptance_criteria": [
          "Capacity provisioned via Python script using AzureCliCredential (no secrets)",
          "Auto-pause triggered when capacity utilisation < 10% for 30 minutes",
          "Scale-up alert fires when Phase 1 throttling detected (>70% CU)",
          "All resources tagged: environment, domain, cost-centre, owner",
          "Script is idempotent — re-running does not create duplicates",
        ],
        "tasks": [
          "ARM REST API call to create Fabric capacity (F64 SKU)",
          "Implement pause/resume with Azure SDK",
          "Tag strategy: env / domain / cost-centre / data-mesh-plane",
          "CU utilisation metric → Log Analytics alert rule",
          "Document capacity sizing guide (F2 dev, F16 test, F64 prod)",
        ]
      },
      {
        "key": "INFRA-2", "summary": "POC: Workspace-per-domain automated provisioning",
        "points": 8, "priority": "High", "poc_file": "poc/01_infrastructure/provision_workspace.py",
        "description": (
          "Each data domain team owns their Fabric workspace. "
          "Automate workspace creation, capacity assignment, default settings, "
          "and item-level role assignment aligned to the federated data mesh model. "
          "No default workspace roles — all grants are item-scoped via Immuta data contracts."
        ),
        "acceptance_criteria": [
          "Workspace created per domain via Fabric REST API",
          "Assigned to correct capacity via workspaceId → capacityId mapping",
          "Item-level roles assigned to domain MSI, reader group, PBI SPN",
          "No default workspace-level Viewer/Member/Contributor roles used",
          "Workspace config (identity, schema, networking) applied via script",
          "Repeatable: CI/CD pipeline can onboard new domain in < 10 min",
        ],
        "tasks": [
          "POST /workspaces — create workspace with displayName, capacityId",
          "Assign item-level roles: Lakehouse ReadWriteAll (domain MSI), ReadAll (PBI SPN)",
          "Suppress default workspace roles via admin API",
          "Create dbo schema in each Lakehouse via REST",
          "CI/CD template: GitHub Actions workflow for new domain onboarding",
        ]
      },
      {
        "key": "INFRA-3", "summary": "POC: Private networking — VNet, Private Endpoints, DNS",
        "points": 13, "priority": "High", "poc_file": "poc/01_infrastructure/provision_networking.py",
        "description": (
          "Enable Fabric managed private endpoints and Azure Private Link for ADLS. "
          "Ensures all data traffic stays on Microsoft backbone — no public internet exposure. "
          "DNS resolution via Azure Private DNS zones. "
          "Network Security Groups for ingress control."
        ),
        "acceptance_criteria": [
          "ADLS private endpoint created in customer VNet",
          "Fabric managed private endpoint approved for ADLS connection",
          "Private DNS zone dfs.core.windows.net resolves to private IP",
          "Storage firewall: deny all public, allow Fabric managed VNet only",
          "Network topology documented: hub-spoke or standalone VNet",
          "Wiz confirms: zero public exposure on ADLS storage account",
        ],
        "tasks": [
          "Create private endpoint for ADLS Gen2 (subresource: dfs)",
          "Request Fabric managed private endpoint via Admin API",
          "Azure Private DNS zone: privatelink.dfs.core.windows.net",
          "NSG rules: deny internet inbound, allow VNet inbound only",
          "Validate: mssparkutils.fs.ls works over private endpoint",
          "Wiz scan confirmation: no public blob access",
        ]
      },
      {
        "key": "INFRA-4", "summary": "POC: Federated identity model — Entra groups, PIM, Immuta automation",
        "points": 13, "priority": "High", "poc_file": "poc/01_infrastructure/provision_identity.py",
        "description": (
          "Establish the federated identity model for data mesh. "
          "Central platform team owns the identity scaffolding; domain teams self-serve "
          "via Immuta data contracts. "
          "PIM for privileged access. Automated Immuta contract provisioning per new domain."
        ),
        "acceptance_criteria": [
          "Entra security groups created per domain: {domain}-data-readers, {domain}-data-writers",
          "Workspace MSI registered as Immuta subject with correct attributes (domain, clearance)",
          "Immuta data contracts auto-provisioned for raw/silver/gold per new domain",
          "PIM configured: Contributor role requires approval + justification, 4h max",
          "No standing Contributor access — all elevated via PIM JIT",
          "Immuta entitlement review scheduled quarterly via API",
        ],
        "tasks": [
          "Microsoft Graph API: create Entra security groups per domain template",
          "Immuta API: register workspace MSI as subject with ABAC attributes",
          "Immuta API: create data contract template for raw/silver/gold zones",
          "PIM API: configure role assignment policy (approval, duration, MFA)",
          "Automation: new domain onboarding triggers Immuta contract creation",
          "Quarterly entitlement review report via Immuta API",
        ]
      },
    ]
  },

  # ── EPIC 2: DATA INGESTION — ON-PREM TO CLOUD ──────────────────────────────
  {
    "key": "INGEST", "type": "Epic", "priority": "High",
    "component": "Data Platform Plane",
    "color": "#f59e0b",
    "summary": "Data Ingestion — On-Prem to Cloud, Test Data Generation, ADLS Upload",
    "description": (
      "Baseline POC demonstrating how data moves from an on-premises SQL source "
      "(simulated) to ADLS Gen2 raw-zone. Covers extraction patterns, "
      "incremental vs full load, metadata tagging, and upload verification. "
      "Forms the foundation for all downstream pipeline stages."
    ),
    "stories": [
      {
        "key": "INGEST-1", "summary": "POC: Simulate on-premises SQL source and extract to parquet",
        "points": 5, "priority": "High", "poc_file": "poc/02_ingestion/simulate_onprem.py",
        "description": (
          "Simulate an on-premises SQL Server source using SQLite + TPC-DS schema. "
          "Demonstrates the extraction pattern: full load for dimensions, "
          "incremental (watermark-based) for fact tables. "
          "Output: partitioned parquet files with extraction metadata."
        ),
        "acceptance_criteria": [
          "SQLite database populated with TPC-DS schema and synthetic data",
          "Full extract: all dimension tables → parquet with schema validation",
          "Incremental extract: fact tables filtered by last_modified watermark",
          "Extraction metadata written: row count, schema hash, extract timestamp",
          "Parquet output partitioned by table name, ready for ADLS upload",
        ],
        "tasks": [
          "SQLite TPC-DS schema creation script",
          "Full extract: pandas → parquet with pyarrow schema enforcement",
          "Incremental extract: watermark table tracks last extracted timestamp",
          "Schema drift detection: compare current vs expected schema hash",
          "Extraction manifest JSON: table, rows, schema_hash, extracted_at",
        ]
      },
      {
        "key": "INGEST-2", "summary": "POC: Upload to ADLS Gen2 with lineage metadata tagging",
        "points": 5, "priority": "High", "poc_file": "poc/02_ingestion/upload_to_adls.py",
        "description": (
          "Upload extracted parquet files to ADLS raw-zone with blob metadata tags "
          "that carry lineage provenance (source system, extract timestamp, schema version). "
          "Demonstrates the on-prem → cloud movement pattern with full observability."
        ),
        "acceptance_criteria": [
          "Files uploaded to raw-zone/tpcds/tables/{table}/ with correct structure",
          "Blob metadata tags: source_system, extract_ts, schema_version, row_count, env",
          "Upload manifest written to raw-zone/_manifests/{date}/{table}.json",
          "Checksum validation: SHA-256 verified post-upload",
          "Upload metrics emitted to Log Analytics: bytes, files, duration, errors",
          "Retry logic: 3× exponential backoff on transient failures",
        ],
        "tasks": [
          "azure-storage-blob SDK upload with metadata dict",
          "SHA-256 checksum: compute pre-upload, verify post-upload",
          "Manifest JSON: upload_id, table, blob_path, size_bytes, checksum, tags",
          "Log Analytics custom log: DataIngestionUpload event",
          "Retry wrapper with exponential backoff (tenacity library)",
        ]
      },
      {
        "key": "INGEST-3", "summary": "POC: Incremental load pattern with watermark and CDC simulation",
        "points": 8, "priority": "Medium", "poc_file": "poc/02_ingestion/incremental_load.py",
        "description": (
          "Demonstrate incremental data loading from on-prem to ADLS using watermark-based "
          "change tracking. Simulates Change Data Capture (CDC) by tracking insert/update/delete "
          "operations. Sets foundation for near-real-time ingestion patterns."
        ),
        "acceptance_criteria": [
          "Watermark table persisted in ADLS _control/watermarks/{table}.json",
          "Only rows with modified_date > last_watermark extracted per run",
          "CDC simulation: separate files for inserts, updates, deletes",
          "Watermark atomically updated only on successful upload",
          "Duplicate detection: row hash prevents re-processing same data",
        ],
        "tasks": [
          "Watermark store: read/write JSON from ADLS _control/ prefix",
          "SQL extract with WHERE modified_date > :watermark parameter",
          "CDC partition: _operation column (I/U/D) appended to parquet",
          "Atomic watermark update with optimistic concurrency check",
          "Dedup hash: SHA-256 of primary key + modified_date columns",
        ]
      },
    ]
  },

  # ── EPIC 3: EVENT-DRIVEN PIPELINE ─────────────────────────────────────────
  {
    "key": "EVENT", "type": "Epic", "priority": "High",
    "component": "Data Platform Plane",
    "color": "#8b5cf6",
    "summary": "Event-Driven Pipeline — Blob Events → Service Bus → Fabric Job Trigger",
    "description": (
      "Replace polling-based pipeline triggers with event-driven architecture. "
      "Azure Event Grid detects new blobs in raw-zone → Service Bus queue → "
      "consumer triggers Fabric CopyJob or notebook (for complex silver transforms). "
      "Enables near-real-time data product refresh with full audit trail."
    ),
    "stories": [
      {
        "key": "EVENT-1", "summary": "POC: Event Grid subscription on ADLS blob created events",
        "points": 8, "priority": "High", "poc_file": "poc/03_event_pipeline/setup_event_grid.py",
        "description": (
          "Create Azure Event Grid system topic on the ADLS account. "
          "Subscribe to Microsoft.Storage.BlobCreated events filtered to raw-zone/tpcds/tables/ prefix. "
          "Route events to Service Bus topic with dead-letter queue."
        ),
        "acceptance_criteria": [
          "Event Grid system topic created on ADLS storage account",
          "Subscription filters: eventType=BlobCreated, subject prefix=tpcds/tables/",
          "Events routed to Service Bus topic: tpcds-raw-ingest",
          "Dead-letter queue configured on Service Bus subscription",
          "Event schema validated: includes table name, blob path, size, timestamp",
          "End-to-end latency: blob created → event received < 30 seconds",
        ],
        "tasks": [
          "ARM/SDK: create Event Grid system topic on storage account",
          "Event subscription with advanced filter: subject begins with prefix",
          "Service Bus namespace + topic + subscription creation",
          "Dead-letter: max delivery count 3, TTL 24h",
          "Test: upload test blob, verify event appears in Service Bus",
        ]
      },
      {
        "key": "EVENT-2", "summary": "POC: Service Bus consumer triggers Fabric CopyJob or Notebook",
        "points": 13, "priority": "High", "poc_file": "poc/03_event_pipeline/trigger_fabric_job.py",
        "description": (
          "Python consumer process reads from Service Bus queue, "
          "parses blob event to determine table name, "
          "then triggers the corresponding Fabric CopyJob (simple tables) "
          "or Silver notebook (complex transforms requiring PySpark). "
          "Implements idempotency, dedup, and dead-letter handling."
        ),
        "acceptance_criteria": [
          "Consumer reads Service Bus messages with peek-lock (not destructive)",
          "Table name extracted from blob path: tpcds/tables/{table}/filename.parquet",
          "CopyJob triggered for dimension tables (< 1M rows, no complex logic)",
          "Silver notebook triggered for fact tables (store_sales, catalog_sales, web_sales)",
          "Message completed only after Fabric job confirms success",
          "Duplicate detection: message_id checked against processed log",
          "Dead-letter handler: alert + manual review queue",
          "Full audit trail: event_id, trigger_time, job_id, status written to Log Analytics",
        ],
        "tasks": [
          "ServiceBusClient with DefaultAzureCredential (MSI)",
          "Message parser: extract table, blob_path, row_count from event body",
          "Routing table: dimension tables → CopyJob, fact tables → Notebook",
          "Fabric REST trigger with retry and run_id extraction from Location header",
          "Poll Fabric job status until terminal state (succeeded/failed)",
          "Complete vs abandon message based on job outcome",
          "Idempotency log: persist processed message_ids to ADLS _control/processed/",
          "Dead-letter alert: send to Log Analytics custom log",
        ]
      },
      {
        "key": "EVENT-3", "summary": "POC: Event-driven silver trigger for complex fact table transforms",
        "points": 8, "priority": "Medium", "poc_file": "poc/03_event_pipeline/event_silver_trigger.py",
        "description": (
          "When all required fact tables for a silver domain have landed in raw-zone, "
          "trigger silver notebook. Uses a coordination pattern: "
          "track which tables have arrived, fire when all dependencies satisfied. "
          "Prevents partial silver runs when source tables arrive at different times."
        ),
        "acceptance_criteria": [
          "Dependency manifest defines which raw tables must arrive before silver triggers",
          "State tracked in ADLS _control/silver_readiness/{domain}/{run_date}.json",
          "Silver notebook triggered only when all dependencies marked 'arrived'",
          "Timeout: if not all tables arrive within 4h, alert and partial-run policy applies",
          "Re-entrancy safe: duplicate events do not trigger duplicate silver runs",
        ],
        "tasks": [
          "Dependency manifest: YAML config per domain listing required raw tables",
          "State machine: pending → partial → ready → triggered → done",
          "Coordination store: atomic read-modify-write on ADLS state JSON",
          "Timeout watcher: Azure Function or scheduler checks stale states hourly",
          "Partial run policy: configurable per domain (block vs proceed with available)",
        ]
      },
    ]
  },

  # ── EPIC 4: DATA ENGINEERING — ETL ────────────────────────────────────────
  {
    "key": "DE", "type": "Epic", "priority": "High",
    "component": "Data Product Plane",
    "color": "#10b981",
    "summary": "Data Engineering — Silver & Gold ETL, Warehouse Load, Data Contracts",
    "description": (
      "Data engineering layer owned by domain teams. "
      "Silver: cleansing, conforming, DQ validation. "
      "Gold: business models, aggregations, curated for consumption. "
      "Warehouse: Fabric Warehouse for SQL-based ETL and BI tool compatibility. "
      "All data stays in tenant ADLS — Lakehouse is catalog only."
    ),
    "stories": [
      {
        "key": "DE-1", "summary": "POC: Silver transform notebook with DQ framework and Immuta governance",
        "points": 8, "priority": "High", "poc_file": "poc/04_data_engineering/silver_transform.py",
        "description": (
          "Silver PySpark notebook: reads from Lakehouse shortcuts (raw Iceberg), "
          "applies DQ rules, writes clean Iceberg to ADLS silver zone. "
          "Auth via workspace MSI (no secrets). "
          "DQ metrics emitted to Log Analytics. "
          "Immuta data contract dc-tpcds-silver-001 governs write access."
        ),
        "acceptance_criteria": [
          "All 24 TPC-DS tables processed with explicit DQ rules per table",
          "DQ metrics table written: table, rule, pass_count, fail_count, fail_rate",
          "Fail rate > 5% on any critical column blocks write and alerts",
          "Auth: workspace MSI OAuth — zero account keys or PATs",
          "Iceberg tables written with explicit LOCATION in tenant ADLS",
          "Run metadata: duration, rows_in, rows_out, dq_pass_rate written to audit log",
        ],
        "tasks": [
          "DQ framework: rule registry (not_null, range, regex, referential) per column",
          "DQ metrics DataFrame → iceberg.dbo.dq_metrics Iceberg table",
          "Alert threshold: Log Analytics alert rule on dq_fail_rate > 0.05",
          "MSI OAuth token acquisition via mssparkutils.credentials.getToken",
          "Audit log: mssparkutils.notebook.exit with JSON summary",
        ]
      },
      {
        "key": "DE-2", "summary": "POC: Gold curation with business models and RFM segmentation",
        "points": 8, "priority": "High", "poc_file": "poc/04_data_engineering/gold_curated.py",
        "description": (
          "Gold PySpark notebook: reads silver Iceberg from ADLS, produces "
          "gold_sales_fact, gold_customer_360 (LTV + RFM), gold_product_performance. "
          "Gold is the data product — owned by the domain team, governed by Immuta contract."
        ),
        "acceptance_criteria": [
          "gold_sales_fact: unified STORE/CATALOG/WEB with returns joined",
          "gold_customer_360: RFM segmentation, LTV, preferred channel",
          "gold_product_performance: margin tier, velocity, return rate, revenue rank",
          "Validation output printed: row counts per table per channel",
          "Iceberg table properties set: owner, domain, data_contract, sensitivity_label",
        ],
        "tasks": [
          "Union of store_sales + catalog_sales + web_sales with returns join",
          "RFM: ntile(5) on recency/frequency/monetary with segment labels",
          "Product: dense_rank() on net_sales, margin tier classification",
          "Iceberg table properties: SET TBLPROPERTIES ('owner'='domain-team')",
          "Write validation: count assertion vs previous run (± 10% alert)",
        ]
      },
      {
        "key": "DE-3", "summary": "POC: Fabric Warehouse — provision and load gold models via SQL",
        "points": 13, "priority": "High", "poc_file": "poc/05_warehouse/provision_warehouse.py",
        "description": (
          "Provision a Fabric Warehouse item alongside the Lakehouse. "
          "Load gold Iceberg tables into Warehouse via COPY INTO or CREATE TABLE AS SELECT. "
          "Warehouse enables SQL-native ETL, stored procedures, and T-SQL compatibility "
          "for data engineering teams who prefer SQL over PySpark."
        ),
        "acceptance_criteria": [
          "Fabric Warehouse created via REST API in target workspace",
          "Shortcut from Warehouse → ADLS gold Iceberg registered",
          "CTAS: gold_sales_fact, gold_customer_360, gold_product_performance created in Warehouse",
          "Warehouse connection string documented for BI tools (JDBC/ODBC)",
          "Row counts validated: Warehouse counts match Iceberg source counts",
          "Incremental refresh: MERGE INTO pattern for delta loads",
        ],
        "tasks": [
          "POST /workspaces/{id}/items — type: Warehouse",
          "Warehouse shortcut: point to prepared-zone Iceberg gold tables",
          "T-SQL CTAS: CREATE TABLE gold.sales_fact AS SELECT * FROM shortcut",
          "MERGE INTO for incremental: match on transaction_id, upsert",
          "JDBC connection string extraction from Warehouse properties API",
          "Row count parity test: assert Warehouse == Iceberg source",
        ]
      },
    ]
  },

  # ── EPIC 5: POWER BI & SEMANTIC MODEL ─────────────────────────────────────
  {
    "key": "PBI", "type": "Epic", "priority": "High",
    "component": "Data Product Plane",
    "color": "#f43f5e",
    "summary": "Power BI — Direct Lake Semantic Model, Automated Deployment, Row-Level Security",
    "description": (
      "Create and publish a Power BI semantic model on top of gold Lakehouse shortcuts. "
      "Direct Lake mode: queries hit ADLS directly, no import. "
      "Automated model deployment via Fabric REST API and XMLA endpoint. "
      "Row-Level Security aligned to Immuta data contracts. "
      "Ready for domain team self-service reporting."
    ),
    "stories": [
      {
        "key": "PBI-1", "summary": "POC: Create Power BI semantic model via Fabric REST API",
        "points": 8, "priority": "High", "poc_file": "poc/06_semantic_model/create_semantic_model.py",
        "description": (
          "Automate creation of a Direct Lake semantic model pointing to gold Lakehouse tables. "
          "Define measures, relationships, and hierarchies via the Tabular Object Model. "
          "Deploy via Fabric REST API — no manual Power BI Desktop steps."
        ),
        "acceptance_criteria": [
          "Semantic model created via POST /workspaces/{id}/semanticModels",
          "Three tables bound: gold_sales_fact, gold_customer_360, gold_product_performance",
          "Relationships defined: sales_fact[customer_sk] → customer_360[customer_sk]",
          "DAX measures: Total Revenue, Return Rate %, Customer LTV, Avg Discount %",
          "Model refreshed and Direct Lake framing confirmed (no import fallback)",
          "Connection mode: DirectLake — verified via model properties API",
        ],
        "tasks": [
          "Fabric REST: POST /semanticModels with table definitions",
          "Table binding: sourceExpression pointing to Lakehouse shortcut",
          "Relationships JSON: fromTable, fromColumn, toTable, toColumn, crossFilter",
          "DAX measures: [Total Revenue], [Return Rate %], [Customer LTV]",
          "Verify Direct Lake: GET /semanticModels/{id}/datasources — mode=DirectLake",
          "Trigger dataset refresh via POST /semanticModels/{id}/refreshes",
        ]
      },
      {
        "key": "PBI-2", "summary": "POC: Row-Level Security aligned to Immuta data contracts",
        "points": 8, "priority": "High", "poc_file": "poc/06_semantic_model/push_rls_model.py",
        "description": (
          "Implement Row-Level Security in the semantic model that mirrors "
          "the Immuta data contract restrictions. Domain analysts see only their domain's data. "
          "RLS roles provisioned via XMLA endpoint — automation replaces manual Power BI Desktop steps."
        ),
        "acceptance_criteria": [
          "RLS role created per domain: filter gold_sales_fact[domain] = USERPRINCIPALNAME()",
          "RLS role assigned to Entra security group {domain}-data-readers",
          "Test: analyst from domain A cannot see domain B rows",
          "RLS definition stored as code (TMSL JSON) — version-controlled",
          "Automated re-deployment on domain group membership change",
        ],
        "tasks": [
          "XMLA endpoint: TMSL CreateOrReplace with roles array",
          "DAX filter per role: [domain_code] = LEFT(USERPRINCIPALNAME(), FIND('@',...)-1)",
          "Role assignment: Microsoft Graph API → add Entra group to PBI role",
          "Test harness: impersonate user and verify row filter applied",
          "CI/CD: re-deploy RLS on merge to main",
        ]
      },
      {
        "key": "PBI-3", "summary": "POC: Automated semantic model deployment pipeline (CI/CD)",
        "points": 5, "priority": "Medium", "poc_file": "poc/06_semantic_model/deploy_pipeline.py",
        "description": (
          "GitHub Actions workflow that deploys the semantic model on every push to main. "
          "Uses Fabric deployment pipelines API (dev → test → prod promotion). "
          "Enables data product teams to treat their semantic model as code."
        ),
        "acceptance_criteria": [
          "GitHub Actions workflow: on push to main → deploy to dev workspace",
          "Fabric deployment pipeline: dev → test → prod promotion with approval gate",
          "Semantic model definition stored as TMDL/TMSL JSON in source control",
          "Rollback: re-deploy previous commit's model definition on failure",
          "Deployment manifest: version, commit SHA, deployed_by, deployed_at",
        ],
        "tasks": [
          "TMDL model definition serialised to JSON (source-of-truth in Git)",
          "Fabric deployment pipeline API: create pipeline, assign workspaces",
          "GitHub Actions: checkout → deploy to dev → run smoke tests → promote",
          "Smoke test: verify row counts in semantic model post-deployment",
          "Rollback action: re-deploy previous TMDL on failed smoke test",
        ]
      },
    ]
  },

  # ── EPIC 6: OBSERVABILITY ─────────────────────────────────────────────────
  {
    "key": "OBS", "type": "Epic", "priority": "Medium",
    "component": "Infrastructure Plane",
    "color": "#06b6d4",
    "summary": "Logging, Monitoring & Observability — Log Analytics, Alerts, Lineage, SLOs",
    "description": (
      "Platform-wide observability for all data mesh planes. "
      "Structured logging from all pipeline stages to Log Analytics. "
      "Custom dashboards for capacity, DQ, pipeline health, and cost. "
      "SLO tracking per data product. Purview lineage scan automation."
    ),
    "stories": [
      {
        "key": "OBS-1", "summary": "POC: Centralised logging — all pipeline stages → Log Analytics",
        "points": 8, "priority": "High", "poc_file": "poc/07_observability/setup_monitoring.py",
        "description": (
          "Emit structured JSON logs from every pipeline stage (ingestion, CopyJob, "
          "silver, gold, warehouse load, semantic model refresh) to Log Analytics "
          "using the Data Collection API. "
          "Enables cross-stage pipeline lineage and SLO measurement."
        ),
        "acceptance_criteria": [
          "Log Analytics workspace created with 90-day retention",
          "Custom tables: DataPipelineRun, DataQualityMetric, IngestionEvent, JobTrigger",
          "Every stage emits: run_id, stage, table, status, duration_ms, rows, error",
          "KQL dashboard: pipeline health, DQ pass rate, avg duration per stage",
          "Alert rules: stage failure, DQ fail rate > 5%, pipeline duration > SLO",
          "Cost tracking: CU consumption per domain per day query",
        ],
        "tasks": [
          "Log Analytics workspace + DCE (Data Collection Endpoint) creation",
          "DCR (Data Collection Rule): define custom log tables with schema",
          "Python logger class: emit structured JSON to DCE via REST",
          "KQL queries: pipeline health dashboard, DQ trend, cost by domain",
          "Alert rules: Metric alert on custom log query results",
          "Workbook: Azure Monitor workbook JSON definition",
        ]
      },
      {
        "key": "OBS-2", "summary": "POC: Purview lineage scan automation for all Iceberg layers",
        "points": 5, "priority": "Medium", "poc_file": "poc/07_observability/purview_lineage.py",
        "description": (
          "Automate Purview data source registration and scan triggering "
          "for all three Iceberg layers (raw/silver/gold). "
          "Column-level lineage from source SQL → raw → silver → gold → PBI dataset. "
          "Triggered post-pipeline completion."
        ),
        "acceptance_criteria": [
          "Purview data source registered for ADLS prepared-zone",
          "Scan definitions for raw, silver, gold prefixes with Iceberg scanner",
          "Scan triggered automatically after gold notebook completes",
          "Column lineage visible in Purview: source_table.col → silver_col → gold_col",
          "Sensitivity labels auto-applied on scan completion (Internal / Confidential)",
          "Business glossary terms linked to gold table columns",
        ],
        "tasks": [
          "Purview REST API: register ADLS data source in collection",
          "Create scan definition: Iceberg format, filter by path prefix",
          "POST /scans/{id}/runs to trigger scan after pipeline run",
          "Lineage API: verify parent/child entity links post-scan",
          "Label assignment: PUT /entities/bulk with sensitivity label attribute",
          "Glossary term assignment: POST /glossary/terms/{id}/assignedEntities",
        ]
      },
      {
        "key": "OBS-3", "summary": "POC: Data Product SLO dashboard — freshness, quality, availability",
        "points": 5, "priority": "Medium", "poc_file": "poc/07_observability/slo_dashboard.py",
        "description": (
          "Each data product (gold table) has a published SLO: "
          "freshness (max age of data), quality (DQ pass rate), availability (pipeline success rate). "
          "Automated SLO measurement and breach alerting."
        ),
        "acceptance_criteria": [
          "SLO config per data product: freshness_max_hours, dq_pass_rate_min, availability_min",
          "SLO measurement job runs hourly: queries Iceberg metadata + Log Analytics",
          "Breach alert: fires within 5 min of SLO violation",
          "SLO report: 30-day rolling view of all data products",
          "Published in Azure Monitor workbook — accessible to domain teams",
        ],
        "tasks": [
          "SLO config YAML: per-product freshness/quality/availability targets",
          "Freshness: read Iceberg snapshot timestamp from metadata.json",
          "Quality: query DataQualityMetric custom log for DQ pass rate",
          "Availability: query DataPipelineRun for success rate in rolling 24h",
          "KQL: SLO breach query with multi-condition threshold",
          "Azure Monitor workbook: SLO tiles with RAG status",
        ]
      },
    ]
  },

  # ── EPIC 7: GOVERNANCE & MESH EXPERIENCE ──────────────────────────────────
  {
    "key": "GOV", "type": "Epic", "priority": "Medium",
    "component": "Mesh Experience Plane",
    "color": "#6366f1",
    "summary": "Governance & Mesh Experience — Purview Catalogue, Immuta Automation, Data Contracts",
    "description": (
      "Mesh experience plane: makes data discoverable, trustworthy, and governable across domains. "
      "Purview as the unified catalogue. Immuta as the central entitlement engine. "
      "Automated data contract lifecycle. Self-service data product registration."
    ),
    "stories": [
      {
        "key": "GOV-1", "summary": "POC: Automated data product registration in Purview catalogue",
        "points": 8, "priority": "Medium", "poc_file": "poc/07_observability/purview_lineage.py",
        "description": (
          "When a domain team deploys a new gold table, "
          "automatically register it as a Data Product asset in Purview. "
          "Tags: domain, owner, classification, SLO, data contract ID. "
          "Enables mesh-wide data discovery without manual catalogue curation."
        ),
        "acceptance_criteria": [
          "Gold table deployment triggers Purview entity creation automatically",
          "Entity attributes: domain, owner_team, data_contract_id, slo_freshness_hrs, sensitivity",
          "Searchable in Purview catalogue by domain, owner, classification",
          "Related entities linked: Lakehouse shortcut → ADLS path → Iceberg table",
          "Business glossary term suggested on entity creation (ML classification)",
        ],
        "tasks": [
          "Purview Atlas REST API: create custom entity type DataProduct",
          "Post-pipeline hook: gold notebook exit triggers registration script",
          "Entity attributes mapped from Iceberg table properties",
          "Collection assignment: entity placed in {domain} collection",
          "Glossary suggestion: GET /glossary/terms → match on column names",
        ]
      },
      {
        "key": "GOV-2", "summary": "POC: Immuta data contract lifecycle automation",
        "points": 8, "priority": "Medium", "poc_file": "poc/01_infrastructure/provision_identity.py",
        "description": (
          "Automate the full lifecycle of Immuta data contracts: "
          "creation on new domain onboarding, policy updates on schema change, "
          "access request + approval workflow, quarterly entitlement review. "
          "Immuta is the single PDP — all entitlement decisions flow through it."
        ),
        "acceptance_criteria": [
          "New domain onboarding: Immuta data sources + policies created in < 5 min",
          "Schema change: Immuta policy auto-updated when new columns detected",
          "Access request: self-service request → approval → Immuta policy update",
          "Quarterly review: Immuta API generates entitlement report for each contract",
          "Stale access auto-revoked after review period expires",
        ],
        "tasks": [
          "Immuta API: POST /dataSource — register ADLS path as data source",
          "Immuta API: POST /policy — ABAC policy template per zone",
          "Schema change detector: compare Iceberg schema vs Immuta registered schema",
          "Access request workflow: Immuta subscription request → email approval → grant",
          "Quarterly report: GET /subscriptions — list all active entitlements per contract",
        ]
      },
      {
        "key": "GOV-3", "summary": "POC: Wiz custom policy integration and risk remediation workflow",
        "points": 5, "priority": "Medium",
        "poc_file": "poc/07_observability/setup_monitoring.py",
        "description": (
          "Integrate Wiz findings into the platform remediation workflow. "
          "Custom Wiz policies based on data mesh threat model: "
          "exposed storage accounts, overly permissive RBAC, Iceberg metadata leaks. "
          "Findings flow to ITSM (ServiceNow/Jira) for central team triage."
        ),
        "acceptance_criteria": [
          "Wiz cloud connector registered for tenant subscription",
          "3 custom policies active: public blob exposure, standing Contributor, weak TLS",
          "Critical findings: webhook → Jira ticket creation (auto-assigned to platform team)",
          "High findings: daily digest → platform team Slack/Teams channel",
          "Remediation SLA: Critical 4h, High 24h, Medium 72h — tracked in Jira",
        ],
        "tasks": [
          "Wiz API: register cloud connector for Azure subscription",
          "Custom policy YAML: publicBlobExposure, standingContributor, weakTLS",
          "Wiz webhook: POST to Azure Function → create Jira issue via Jira REST API",
          "SLA tracking: Jira automation rule escalates on breach",
          "Monthly posture report: Wiz API → PDF → CISO distribution",
        ]
      },
    ]
  },

]


# ══════════════════════════════════════════════════════════════════════════════
# EXPORT FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def to_jira_json(backlog: list) -> list:
    """Flatten backlog into JIRA-importable issue list."""
    issues = []
    issue_num = 1
    for epic in backlog:
        issues.append({
            "issueType":   "Epic",
            "key":         f"{epic['key']}-0",
            "summary":     epic["summary"],
            "description": epic["description"],
            "priority":    epic.get("priority", "Medium"),
            "labels":      [epic["component"].replace(" ", "-"), "data-mesh"],
            "storyPoints": None,
            "component":   epic["component"],
            "epicLink":    f"{epic['key']}-0",
        })
        for story in epic.get("stories", []):
            issues.append({
                "issueType":   "Story",
                "key":         story["key"],
                "summary":     story["summary"],
                "description": story["description"],
                "acceptanceCriteria": "\n".join(f"- {c}" for c in story.get("acceptance_criteria",[])),
                "priority":    story.get("priority", "Medium"),
                "labels":      [epic["component"].replace(" ", "-"), "data-mesh", "poc"],
                "storyPoints": story.get("points"),
                "component":   epic["component"],
                "epicLink":    f"{epic['key']}-0",
                "pocFile":     story.get("poc_file", ""),
            })
            for i, task in enumerate(story.get("tasks", []), 1):
                issues.append({
                    "issueType":  "Sub-task",
                    "key":        f"{story['key']}-T{i}",
                    "summary":    task,
                    "parentKey":  story["key"],
                    "priority":   "Medium",
                    "labels":     ["task"],
                    "storyPoints": 1,
                    "component":  epic["component"],
                    "epicLink":   f"{epic['key']}-0",
                })
    return issues


def sprint_velocity(backlog: list) -> dict:
    """Compute story points per epic."""
    totals = {}
    for epic in backlog:
        pts = sum(s.get("points", 0) for s in epic.get("stories", []))
        totals[epic["key"]] = {"summary": epic["summary"][:60], "points": pts}
    return totals


def generate_html(backlog: list) -> str:
    velocity = sprint_velocity(backlog)
    total_pts = sum(v["points"] for v in velocity.values())
    total_stories = sum(len(e.get("stories", [])) for e in backlog)
    total_tasks = sum(
        sum(len(s.get("tasks", [])) for s in e.get("stories", []))
        for e in backlog
    )

    priority_color = {"High": "#f43f5e", "Medium": "#f59e0b", "Low": "#10b981"}

    epic_cards = ""
    for epic in backlog:
        story_rows = ""
        for story in epic.get("stories", []):
            ac_html = "".join(
                f'<li>{c}</li>' for c in story.get("acceptance_criteria", [])
            )
            task_html = "".join(
                f'<div class="task-chip">{t}</div>'
                for t in story.get("tasks", [])
            )
            pc = priority_color.get(story.get("priority", "Medium"), "#64748b")
            poc = story.get("poc_file", "")
            poc_badge = f'<span class="poc-badge">📄 {poc}</span>' if poc else ""
            story_rows += f"""
            <div class="story-card">
              <div class="story-header">
                <span class="story-key">{story["key"]}</span>
                <span class="priority-dot" style="background:{pc}" title="{story.get('priority')}"></span>
                <span class="story-pts">{story.get("points","?")}pt</span>
              </div>
              <div class="story-summary">{story["summary"]}</div>
              <div class="story-desc">{story["description"]}</div>
              {poc_badge}
              <div class="ac-section">
                <div class="ac-title">Acceptance Criteria</div>
                <ul class="ac-list">{ac_html}</ul>
              </div>
              <div class="tasks-section">
                <div class="tasks-title">Sub-tasks ({len(story.get("tasks",[]))})</div>
                <div class="tasks-chips">{task_html}</div>
              </div>
            </div>"""

        vel = velocity.get(epic["key"], {})
        epic_cards += f"""
        <div class="epic-block">
          <div class="epic-header" style="border-left:4px solid {epic["color"]}">
            <div class="epic-left">
              <span class="epic-badge" style="background:{epic["color"]}20;color:{epic["color"]};border:1px solid {epic["color"]}40">{epic["key"]}</span>
              <div>
                <div class="epic-title">{epic["summary"]}</div>
                <div class="epic-component">{epic["component"]}</div>
              </div>
            </div>
            <div class="epic-meta">
              <span class="epic-pts">{vel.get("points",0)} pts</span>
              <span class="epic-stories">{len(epic.get("stories",[]))} stories</span>
            </div>
          </div>
          <div class="epic-desc">{epic["description"]}</div>
          <div class="stories-grid">
            {story_rows}
          </div>
        </div>"""

    plane_summary = {
        "Infrastructure Plane": {"color": "#0ea5e9", "epics": ["INFRA", "OBS"]},
        "Data Platform Plane":  {"color": "#f59e0b", "epics": ["INGEST", "EVENT"]},
        "Data Product Plane":   {"color": "#10b981", "epics": ["DE", "PBI"]},
        "Mesh Experience Plane":{"color": "#6366f1", "epics": ["GOV"]},
    }
    plane_html = ""
    for plane, meta in plane_summary.items():
        pts = sum(velocity.get(k, {}).get("points", 0) for k in meta["epics"])
        plane_html += f"""
        <div class="plane-card" style="border-top:3px solid {meta['color']}">
          <div class="plane-name">{plane}</div>
          <div class="plane-pts" style="color:{meta['color']}">{pts} pts</div>
          <div class="plane-epics">{"  ".join(f'<span class="epic-tag" style="color:{meta["color"]};border-color:{meta["color"]}40">{k}</span>' for k in meta["epics"])}</div>
        </div>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Data Mesh Platform — JIRA Backlog</title>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root{{--bg:#07090f;--surface:#0c111c;--card:#0f1623;--border:#1a2640;--text:#e2e8f0;--muted:#4b6080;--mono:'IBM Plex Mono',monospace;--sans:'IBM Plex Sans',sans-serif}}
*,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--text);font-family:var(--sans);font-size:12px;line-height:1.5}}
body::before{{content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(0,212,255,.02) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,.02) 1px,transparent 1px);background-size:32px 32px;pointer-events:none;z-index:0}}
.page{{position:relative;z-index:1;max-width:1400px;margin:0 auto;padding:32px 24px}}
header{{border-bottom:1px solid var(--border);padding-bottom:20px;margin-bottom:28px;display:flex;justify-content:space-between;align-items:flex-start;gap:20px}}
h1{{font-size:20px;font-weight:600;color:#fff;margin-bottom:3px}}
.hsub{{font-family:var(--mono);font-size:9px;color:var(--muted)}}
.hstats{{display:flex;gap:16px;flex-wrap:wrap}}
.hstat{{text-align:center;padding:8px 14px;background:var(--card);border:1px solid var(--border);border-radius:3px}}
.hstat-val{{font-size:18px;font-weight:600;color:#fff;font-family:var(--mono)}}
.hstat-label{{font-size:8px;color:var(--muted);font-family:var(--mono);letter-spacing:.1em;text-transform:uppercase}}
.planes-row{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:28px}}
.plane-card{{background:var(--card);border:1px solid var(--border);border-radius:4px;padding:12px 14px}}
.plane-name{{font-size:10px;font-weight:600;color:var(--text);margin-bottom:5px}}
.plane-pts{{font-family:var(--mono);font-size:18px;font-weight:600;margin-bottom:5px}}
.plane-epics{{display:flex;gap:5px;flex-wrap:wrap}}
.epic-tag{{font-family:var(--mono);font-size:8px;padding:1px 6px;border-radius:2px;border:1px solid}}
.epic-block{{margin-bottom:24px;background:var(--surface);border:1px solid var(--border);border-radius:5px;overflow:hidden}}
.epic-header{{padding:14px 16px;display:flex;justify-content:space-between;align-items:center;gap:12px;background:rgba(255,255,255,.015)}}
.epic-left{{display:flex;align-items:center;gap:10px}}
.epic-badge{{font-family:var(--mono);font-size:9px;font-weight:600;padding:2px 8px;border-radius:2px;letter-spacing:.08em}}
.epic-title{{font-size:12px;font-weight:600;color:#fff}}
.epic-component{{font-family:var(--mono);font-size:8px;color:var(--muted);letter-spacing:.1em;text-transform:uppercase;margin-top:1px}}
.epic-meta{{display:flex;gap:8px;align-items:center;flex-shrink:0}}
.epic-pts{{font-family:var(--mono);font-size:11px;color:#f59e0b;font-weight:600}}
.epic-stories{{font-family:var(--mono);font-size:9px;color:var(--muted)}}
.epic-desc{{padding:10px 16px;font-size:10px;color:#5a7090;border-bottom:1px solid var(--border)}}
.stories-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(380px,1fr));gap:1px;background:var(--border)}}
.story-card{{background:var(--card);padding:14px;position:relative}}
.story-header{{display:flex;align-items:center;gap:6px;margin-bottom:6px}}
.story-key{{font-family:var(--mono);font-size:9px;color:#0ea5e9;font-weight:600}}
.priority-dot{{width:6px;height:6px;border-radius:50%;margin-left:2px}}
.story-pts{{font-family:var(--mono);font-size:9px;color:#f59e0b;margin-left:auto;font-weight:600}}
.story-summary{{font-size:11px;font-weight:600;color:var(--text);margin-bottom:5px;line-height:1.4}}
.story-desc{{font-size:9px;color:#4b6080;margin-bottom:8px;line-height:1.5}}
.poc-badge{{display:inline-block;font-family:var(--mono);font-size:8px;color:#10b981;background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.2);padding:2px 7px;border-radius:2px;margin-bottom:7px}}
.ac-section,.tasks-section{{margin-top:8px}}
.ac-title,.tasks-title{{font-family:var(--mono);font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);margin-bottom:4px}}
.ac-list{{list-style:none;display:flex;flex-direction:column;gap:3px}}
.ac-list li{{font-size:9px;color:#5a7090;padding-left:10px;position:relative}}
.ac-list li::before{{content:'✓';position:absolute;left:0;color:#10b981;font-size:8px}}
.tasks-chips{{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px}}
.task-chip{{font-family:var(--mono);font-size:8px;padding:2px 6px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:2px;color:var(--muted)}}
footer{{border-top:1px solid var(--border);padding-top:16px;margin-top:24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}}
.footer-txt{{font-family:var(--mono);font-size:8px;color:var(--muted)}}
.tag{{display:inline-block;font-family:var(--mono);font-size:8px;padding:2px 6px;border-radius:2px;border:1px solid;margin:2px}}
</style>
</head>
<body>
<div class="page">
<header>
  <div>
    <div style="font-family:var(--mono);font-size:9px;letter-spacing:.2em;color:#0ea5e9;background:rgba(14,165,233,.07);border:1px solid rgba(14,165,233,.2);padding:3px 8px;border-radius:2px;display:inline-block;margin-bottom:7px">DATA MESH PLATFORM — JIRA BACKLOG</div>
    <h1>Data Platform Engineering — Full Backlog</h1>
    <div class="hsub">Multi-plane Data Mesh · Fabric · ADLS · Immuta · Purview · Wiz · Generated {TODAY}</div>
  </div>
  <div class="hstats">
    <div class="hstat"><div class="hstat-val">{total_pts}</div><div class="hstat-label">Story Points</div></div>
    <div class="hstat"><div class="hstat-val">{len(backlog)}</div><div class="hstat-label">Epics</div></div>
    <div class="hstat"><div class="hstat-val">{total_stories}</div><div class="hstat-label">Stories</div></div>
    <div class="hstat"><div class="hstat-val">{total_tasks}</div><div class="hstat-label">Sub-tasks</div></div>
    <div class="hstat"><div class="hstat-val">~{total_pts//10}w</div><div class="hstat-label">Est. Duration</div></div>
  </div>
</header>

<div class="planes-row">{plane_html}</div>

{epic_cards}

<footer>
  <div class="footer-txt">Data Mesh Platform Backlog · Classification: INTERNAL · {TODAY}</div>
  <div>
    <span class="tag" style="color:#0ea5e9;border-color:rgba(14,165,233,.3)">Infrastructure Plane</span>
    <span class="tag" style="color:#f59e0b;border-color:rgba(245,158,11,.3)">Data Platform Plane</span>
    <span class="tag" style="color:#10b981;border-color:rgba(16,185,129,.3)">Data Product Plane</span>
    <span class="tag" style="color:#6366f1;border-color:rgba(99,102,241,.3)">Mesh Experience Plane</span>
  </div>
</footer>
</div>
</body>
</html>"""


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    # JSON export (JIRA importable)
    issues = to_jira_json(BACKLOG)
    json_path = OUT / "jira_export.json"
    json_path.write_text(json.dumps(issues, indent=2))
    print(f"✓ JIRA JSON export  → {json_path}  ({len(issues)} issues)")

    # Velocity summary
    velocity = sprint_velocity(BACKLOG)
    total = sum(v["points"] for v in velocity.values())
    print(f"\n── Story Point Summary (total: {total} pts, ~{total//10} weeks @ 10pt/week) ──")
    for k, v in velocity.items():
        bar = "█" * (v["points"] // 2)
        print(f"  {k:8s}  {v['points']:3d}pt  {bar}  {v['summary']}")

    # HTML board
    html = generate_html(BACKLOG)
    html_path = OUT / "jira_board.html"
    html_path.write_text(html)
    print(f"\n✓ JIRA board HTML   → {html_path}")

    if "--no-browser" not in sys.argv:
        webbrowser.open(str(html_path))
        print("  (opening in browser)")
